from django.core.management.base import BaseCommand
from django.db import connection, transaction
import os

class Command(BaseCommand):
    help = 'Fix inconsistent migrations for standards app'

    def handle(self, *args, **options):
        self.stdout.write(self.style.WARNING('Starting fix for standards migrations...'))
        
        try:
            # First check if migration files exist, create them if needed
            self.ensure_migration_files()
            
            with transaction.atomic():
                # 1. Check current migration state
                with connection.cursor() as cursor:
                    cursor.execute("""
                        SELECT name FROM django_migrations 
                        WHERE app = 'standards'
                        ORDER BY id
                    """)
                    applied_migrations = [row[0] for row in cursor.fetchall()]
                
                self.stdout.write(f"Current migrations: {', '.join(applied_migrations) if applied_migrations else 'None'}")
                
                # Check if migrations are already in a good state
                expected_migrations = set([
                    '0001_initial',
                    '0002_standardsection_level_standardsection_lft_and_more',
                    '0003_fix_mptt_fields',
                    '0004_standardsection_fields'
                ])
                
                if set(applied_migrations) == expected_migrations and len(applied_migrations) == len(expected_migrations):
                    self.stdout.write(self.style.SUCCESS('Migrations are already in the correct state. No changes needed.'))
                    return
                
                # Ask for confirmation before making changes
                self.stdout.write(self.style.WARNING(
                    '\nThis will reset all standards migrations and may affect your database.\n'
                    'This is necessary to fix migration errors, but should only be done if you are experiencing issues.\n'
                    'Yesterday\'s configuration may have been working fine, but something changed in the environment.\n'
                ))
                
                confirm = input('Are you sure you want to continue? (yes/no): ').lower().strip()
                if confirm not in ('yes', 'y'):
                    self.stdout.write(self.style.WARNING('Operation cancelled.'))
                    return
                
                # 2. Remove all standards migrations
                with connection.cursor() as cursor:
                    cursor.execute("""
                        DELETE FROM django_migrations 
                        WHERE app = 'standards'
                    """)
                
                self.stdout.write(self.style.SUCCESS('Removed all standards migrations from database'))
                
                # 3. Insert the migrations in the correct order
                migrations = [
                    '0001_initial',  # Base migration
                    '0002_standardsection_level_standardsection_lft_and_more',  # MPTT fields
                    '0003_fix_mptt_fields',  # Fix for MPTT fields
                    '0004_standardsection_fields',  # Additional fields
                ]
                
                for migration in migrations:
                    with connection.cursor() as cursor:
                        cursor.execute("""
                            INSERT INTO django_migrations (app, name, applied)
                            VALUES (%s, %s, NOW())
                        """, ['standards', migration])
                    
                    self.stdout.write(f"Added migration: {migration}")
                
                self.stdout.write(self.style.SUCCESS('Migrations fixed in correct order'))
                
                # 4. Verify the fix
                with connection.cursor() as cursor:
                    cursor.execute("""
                        SELECT name FROM django_migrations 
                        WHERE app = 'standards'
                        ORDER BY id
                    """)
                    new_migrations = [row[0] for row in cursor.fetchall()]
                
                self.stdout.write(f"New migrations: {', '.join(new_migrations)}")
                
                # 5. Fix database structure if needed
                self.ensure_table_structure()
                
                self.stdout.write(self.style.SUCCESS('Migration history fixed successfully!'))
                self.stdout.write(self.style.SUCCESS('You can now run Django commands without migration errors.'))
                
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error: {str(e)}'))
    
    def ensure_table_structure(self):
        """Make sure the database tables match our expectations"""
        try:
            # First check if tables exist
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables 
                        WHERE table_name = 'standards_standardsection'
                    )
                """)
                section_table_exists = cursor.fetchone()[0]
                
                cursor.execute("""
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables 
                        WHERE table_name = 'standards_standardsubsection'
                    )
                """)
                subsection_table_exists = cursor.fetchone()[0]
            
            # Create or fix StandardSection table if needed
            if not section_table_exists:
                self.stdout.write('Creating standards_standardsection table...')
                with connection.cursor() as cursor:
                    cursor.execute("""
                        CREATE TABLE standards_standardsection (
                            id SERIAL PRIMARY KEY,
                            section_number VARCHAR(50),
                            title TEXT,
                            title_user TEXT,
                            content TEXT,
                            display_order INTEGER DEFAULT 0,
                            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                            level INTEGER DEFAULT 0,
                            lft INTEGER DEFAULT 0,
                            rght INTEGER DEFAULT 0,
                            tree_id INTEGER DEFAULT 0,
                            parent_id INTEGER REFERENCES standards_standardsection(id) ON DELETE CASCADE NULL,
                            standard_id INTEGER NOT NULL REFERENCES standards_standard(id) ON DELETE CASCADE
                        )
                    """)
                self.stdout.write(self.style.SUCCESS('Created standards_standardsection table'))
            else:
                # Ensure all needed columns exist
                self.stdout.write('Checking standards_standardsection columns...')
                with connection.cursor() as cursor:
                    cursor.execute("""
                        SELECT column_name FROM information_schema.columns 
                        WHERE table_name = 'standards_standardsection'
                    """)
                    existing_columns = {row[0] for row in cursor.fetchall()}
                
                columns_to_add = {
                    'section_number': 'VARCHAR(50) NULL',
                    'title': 'TEXT NULL',
                    'title_user': 'TEXT NULL',
                    'content': 'TEXT NULL',
                    'display_order': 'INTEGER DEFAULT 0',
                    'level': 'INTEGER DEFAULT 0',
                    'lft': 'INTEGER DEFAULT 0',
                    'rght': 'INTEGER DEFAULT 0',
                    'tree_id': 'INTEGER DEFAULT 0',
                    'created_at': 'TIMESTAMP WITH TIME ZONE DEFAULT NOW()',
                    'updated_at': 'TIMESTAMP WITH TIME ZONE DEFAULT NOW()'
                }
                
                for column, data_type in columns_to_add.items():
                    if column not in existing_columns:
                        self.stdout.write(f'Adding missing column: {column}')
                        with connection.cursor() as cursor:
                            cursor.execute(f"""
                                ALTER TABLE standards_standardsection 
                                ADD COLUMN {column} {data_type}
                            """)
            
            # Create or fix StandardSubsection table if needed
            if not subsection_table_exists:
                self.stdout.write('Creating standards_standardsubsection table...')
                with connection.cursor() as cursor:
                    cursor.execute("""
                        CREATE TABLE standards_standardsubsection (
                            id SERIAL PRIMARY KEY,
                            subsection_number VARCHAR(20) NOT NULL,
                            title VARCHAR(255) NOT NULL,
                            content TEXT,
                            "order" INTEGER NOT NULL DEFAULT 0,
                            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                            section_id INTEGER NOT NULL REFERENCES standards_standardsection(id) ON DELETE CASCADE
                        )
                    """)
                self.stdout.write(self.style.SUCCESS('Created standards_standardsubsection table'))
            
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error ensuring table structure: {str(e)}'))
    
    def ensure_migration_files(self):
        """Ensure all necessary migration files exist"""
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
