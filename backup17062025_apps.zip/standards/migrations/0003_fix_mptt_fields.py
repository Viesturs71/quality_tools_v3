from django.db import migrations, models

class Migration(migrations.Migration):
    """Migration to fix MPTT fields in StandardSection model"""
    
    dependencies = [
        ('standards', '0002_standardsection_level_standardsection_lft_and_more'),
    ]

    operations = [
        # Convert MPTT fields to proper integer fields
        migrations.AlterField(
            model_name='standardsection',
            name='level',
            field=models.PositiveIntegerField(default=0, editable=False),
        ),
        migrations.AlterField(
            model_name='standardsection',
            name='lft',
            field=models.PositiveIntegerField(default=0, editable=False),
        ),
        migrations.AlterField(
            model_name='standardsection',
            name='rght',
            field=models.PositiveIntegerField(default=0, editable=False),
        ),
        migrations.AlterField(
            model_name='standardsection',
            name='tree_id',
            field=models.PositiveIntegerField(default=0, editable=False),
        ),
    ]
