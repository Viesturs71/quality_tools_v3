# personnel/models.py
from django.contrib.auth import get_user_model
from django.db import models
from django.utils.translation import gettext_lazy as _
from simple_history.models import HistoricalRecords

from company.models import Company

User = get_user_model()

class Department(models.Model):
    name = models.CharField(_('Name'), max_length=100)
    description = models.TextField(_('Description'), blank=True, null=True)
    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name='personnel_departments'  # Changed from 'departments' to 'personnel_departments'
    )
    history = HistoricalRecords()

    class Meta:
        verbose_name = _('Department')
        verbose_name_plural = _('Departments')

    def __str__(self):
        return self.name

class Position(models.Model):
    name = models.CharField(_('Position Name'), max_length=100)
    description = models.TextField(_('Description'), blank=True, null=True)
    history = HistoricalRecords()

    class Meta:
        verbose_name = _('Position')
        verbose_name_plural = _('Positions')

    def __str__(self):
        return self.name

class Field(models.Model):
    name = models.CharField(_('Field Name'), max_length=255)
    description = models.TextField(_('Description'), blank=True, null=True)
    history = HistoricalRecords()

    class Meta:
        verbose_name = _('Field')
        verbose_name_plural = _('Fields')

    def __str__(self):
        return self.name

class Education(models.Model):
    name = models.CharField(_('Name'), max_length=255)
    description = models.TextField(_('Description'), blank=True, null=True)
    history = HistoricalRecords()

    class Meta:
        verbose_name = _('Education')
        verbose_name_plural = _('Education')

    def __str__(self):
        return self.name

class Employee(models.Model):
    """Employee model."""
    first_name = models.CharField(_('First Name'), max_length=100)
    last_name = models.CharField(_('Last Name'), max_length=100)
    email = models.EmailField(_('Email'), unique=True)
    phone = models.CharField(_('Phone'), max_length=20, blank=True, null=True)
    position = models.CharField(_('Position'), max_length=100, blank=True, null=True)
    hire_date = models.DateField(_('Hire Date'), blank=True, null=True)
    department = models.ForeignKey(
        'company.Department',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='employees',
        verbose_name=_('Department')
    )
    is_active = models.BooleanField(_('Active'), default=True)
    notes = models.TextField(_('Notes'), blank=True, null=True)
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='personnel_profile'
    )
    history = HistoricalRecords()

    class Meta:
        verbose_name = _('Employee')
        verbose_name_plural = _('Employees')
        ordering = ['last_name', 'first_name']

    def __str__(self):
        return f"{self.first_name} {self.last_name}"
    
    def save(self, *args, **kwargs):
        """Generate employee_id if not provided."""
        if not self.employee_id:
            last_id = Employee.objects.order_by('-id').first()
            last_num = 1 if not last_id else last_id.id + 1
            self.employee_id = f"EMP-{last_num:05d}"
        super().save(*args, **kwargs)
    def save(self, *args, **kwargs):
        """Generate employee_id if not provided."""
        if not self.employee_id:
            last_id = Employee.objects.order_by('-id').first()
            last_num = 1 if not last_id else last_id.id + 1
            self.employee_id = f"EMP-{last_num:05d}"
        super().save(*args, **kwargs)
