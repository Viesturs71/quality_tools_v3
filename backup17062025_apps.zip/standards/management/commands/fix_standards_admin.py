from django.core.management.base import BaseCommand
from django.db import connection, transaction

class Command(BaseCommand):
    help = 'Fix StandardSection admin view issues'

    def handle(self, *args, **options):
        self.stdout.write(self.style.WARNING('Starting fix for StandardSection admin view...'))
        
        try:
            with transaction.atomic():
                # Check if the revision column exists in the standards_standard table
                with connection.cursor() as cursor:
                    cursor.execute("""
                        SELECT EXISTS (
                            SELECT FROM information_schema.columns 
                            WHERE table_name = 'standards_standard' AND column_name = 'revision'
                        )
                    """)
                    revision_exists = cursor.fetchone()[0]
                
                if not revision_exists:
                    # Add the missing revision column to standards_standard
                    self.stdout.write('Adding missing revision column to standards_standard...')
                    with connection.cursor() as cursor:
                        cursor.execute("""
                            ALTER TABLE standards_standard 
                            ADD COLUMN revision VARCHAR(20) NULL
                        """)
                    self.stdout.write(self.style.SUCCESS('Added revision column to standards_standard'))
                
                # Fix any other missing columns in the standards_standard table
                with connection.cursor() as cursor:
                    cursor.execute("""
                        SELECT column_name FROM information_schema.columns 
                        WHERE table_name = 'standards_standard'
                    """)
                    existing_columns = [row[0] for row in cursor.fetchall()]
                
                # Required fields for Standard model
                required_columns = {
                    'number': 'VARCHAR(50) NOT NULL',
                    'title': 'VARCHAR(255) NOT NULL',
                    'description': 'TEXT NULL',
                    'revision': 'VARCHAR(20) NULL',
                    'issuing_body': 'VARCHAR(100) NULL',
                    'is_active': 'BOOLEAN NOT NULL DEFAULT TRUE',
                    'created_at': 'TIMESTAMP WITH TIME ZONE NULL DEFAULT NOW()',
                    'updated_at': 'TIMESTAMP WITH TIME ZONE NULL DEFAULT NOW()'
                }
                
                # Add missing columns
                for column, data_type in required_columns.items():
                    if column not in existing_columns:
                        self.stdout.write(f'Adding missing column: {column}')
                        with connection.cursor() as cursor:
                            cursor.execute(f"""
                                ALTER TABLE standards_standard 
                                ADD COLUMN {column} {data_type}
                            """)
                
                self.stdout.write(self.style.SUCCESS('Standards admin view fix completed!'))
                
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error: {str(e)}'))
            return
