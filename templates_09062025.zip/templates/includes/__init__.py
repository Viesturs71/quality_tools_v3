"""
Settings includes package for document templates.
"""
