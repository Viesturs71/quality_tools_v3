import os
from django.core.management.base import BaseCommand
from django.db import connection

class Command(BaseCommand):
    help = 'Fix the StandardSection table by adding missing columns'

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS('Starting to fix StandardSection table...'))
        
        # Get existing columns
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = 'standards_standardsection'
            """)
            existing_columns = [row[0] for row in cursor.fetchall()]
        
        # Define required columns with their data types
        required_columns = {
            'section_number': 'VARCHAR(50)',
            'title': 'VARCHAR(255)',
            'content': 'TEXT'
        }
        
        # Add missing columns
        with connection.cursor() as cursor:
            for column, data_type in required_columns.items():
                if column not in existing_columns:
                    self.stdout.write(f'Adding column {column}...')
                    cursor.execute(f"ALTER TABLE standards_standardsection ADD COLUMN {column} {data_type}")
                    self.stdout.write(self.style.SUCCESS(f'Added column {column} successfully!'))
                else:
                    self.stdout.write(f'Column {column} already exists.')
        
        self.stdout.write(self.style.SUCCESS('All required columns have been added to StandardSection table!'))
