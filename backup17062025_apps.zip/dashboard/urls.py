from django.urls import path
from . import views

app_name = 'dashboard'

urlpatterns = [
    path('', views.home_view, name='home'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('index/', views.index_view, name='index'),
]
    # Dashboard view
    path('dashboard/', views.dashboard_view, name='dashboard'),  # Ensure the 'dashboard' view is defined

    # Index view
    path('index/', views.index_view, name='index'),
]
