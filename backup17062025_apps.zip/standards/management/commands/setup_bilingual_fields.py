from django.core.management.base import BaseCommand
from django.db import connection

class Command(BaseCommand):
    help = 'Set up bilingual fields for StandardSection'

    def handle(self, *args, **options):
        self.stdout.write('Setting up bilingual fields for StandardSection...')
        
        # Check if the table exists
        if not self.table_exists('standards_standardsection'):
            self.stdout.write(self.style.WARNING(
                'Table standards_standardsection does not exist. Run migrations first.'
            ))
            return
        
        # Get existing columns
        existing_columns = self.get_columns('standards_standardsection')
        self.stdout.write(f'Found columns: {", ".join(existing_columns)}')
        
        # Define all required columns for bilingual content
        required_columns = {
            'section_number': 'VARCHAR(50) NULL',
            'title': 'VARCHAR(255) NULL',
            'content': 'TEXT NULL',
            'title_en': 'VARCHAR(255) NULL',
            'content_en': 'TEXT NULL',
        }
        
        # Add missing columns
        added_columns = []
        for column, data_type in required_columns.items():
            if column not in existing_columns:
                self.stdout.write(f'Adding column {column}...')
                try:
                    with connection.cursor() as cursor:
                        cursor.execute(f"""
                            ALTER TABLE standards_standardsection 
                            ADD COLUMN {column} {data_type}
                        """)
                    added_columns.append(column)
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error adding column {column}: {e}'))
        
        if added_columns:
            self.stdout.write(self.style.SUCCESS(
                f'Added {len(added_columns)} columns: {", ".join(added_columns)}'
            ))
        else:
            self.stdout.write(self.style.SUCCESS('All required bilingual columns already exist'))
        
        self.stdout.write(self.style.SUCCESS('Bilingual fields setup complete!'))
    
    def table_exists(self, table_name):
        """Check if a table exists in the database"""
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_name = %s
                )
            """, [table_name])
            return cursor.fetchone()[0]
    
    def get_columns(self, table_name):
        """Get a list of column names for a table"""
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = %s
            """, [table_name])
            return [row[0] for row in cursor.fetchall()]
