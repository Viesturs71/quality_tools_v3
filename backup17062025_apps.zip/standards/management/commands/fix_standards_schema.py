from django.core.management.base import BaseCommand
from django.db import connection

class Command(BaseCommand):
    help = 'Fix database schema issues with standards app'

    def handle(self, *args, **options):
        self.stdout.write('Fixing schema issues for standards app...')
        
        # Check and fix StandardSection table
        self.fix_standard_section_table()
        
        self.stdout.write(self.style.SUCCESS('Schema fixes completed!'))
    
    def fix_standard_section_table(self):
        """Fix issues with StandardSection table"""
        self.stdout.write('Checking StandardSection table...')
        
        # Check if table exists
        if not self.table_exists('standards_standardsection'):
            self.stdout.write(self.style.ERROR('Table standards_standardsection does not exist!'))
            self.stdout.write('Run migrations first: python manage.py migrate standards')
            return
            
        # Get existing columns
        existing_columns = self.get_columns('standards_standardsection')
        self.stdout.write(f'Found columns: {", ".join(existing_columns)}')
        
        # Check if problematic 'order' column exists
        if 'order' in existing_columns:
            self.stdout.write('Found problematic "order" column, attempting to remove...')
            try:
                with connection.cursor() as cursor:
                    cursor.execute('ALTER TABLE standards_standardsection DROP COLUMN "order"')
                self.stdout.write(self.style.SUCCESS('Successfully removed "order" column'))
            except Exception as e:
                self.stdout.write(self.style.ERROR(f'Error removing "order" column: {e}'))
                self.stdout.write(self.style.WARNING('Attempting to rename "order" column to "sort_order" instead...'))
                try:
                    with connection.cursor() as cursor:
                        cursor.execute('ALTER TABLE standards_standardsection RENAME COLUMN "order" TO sort_order')
                    self.stdout.write(self.style.SUCCESS('Renamed "order" to "sort_order"'))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error renaming column: {e}'))
        
        # Add required columns
        required_columns = {
            'section_number': 'VARCHAR(50) NULL',
            'title': 'TEXT NULL',
            'title_user': 'TEXT NULL',
            'content': 'TEXT NULL',
        }
        
        # Add missing columns
        for column, data_type in required_columns.items():
            if column not in existing_columns:
                self.stdout.write(f'Adding column {column}...')
                try:
                    with connection.cursor() as cursor:
                        cursor.execute(f"""
                            ALTER TABLE standards_standardsection 
                            ADD COLUMN {column} {data_type}
                        """)
                    self.stdout.write(self.style.SUCCESS(f'Added column {column}'))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error adding column {column}: {e}'))
            else:
                # Convert any varchar title columns to TEXT
                if column.startswith('title') and self.get_column_type(column) == 'character varying':
                    self.stdout.write(f'Converting {column} from VARCHAR to TEXT...')
                    try:
                        with connection.cursor() as cursor:
                            cursor.execute(f"""
                                ALTER TABLE standards_standardsection 
                                ALTER COLUMN {column} TYPE TEXT
                            """)
                        self.stdout.write(self.style.SUCCESS(f'Converted {column} to TEXT'))
                    except Exception as e:
                        self.stdout.write(self.style.ERROR(f'Error converting column {column}: {e}'))
    
    def table_exists(self, table_name):
        """Check if a table exists in the database"""
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_name = %s
                )
            """, [table_name])
            return cursor.fetchone()[0]
    
    def get_columns(self, table_name):
        """Get a list of column names for a table"""
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = %s
            """, [table_name])
            return [row[0] for row in cursor.fetchall()]
    
    def get_column_type(self, column_name, table_name='standards_standardsection'):
        """Get the data type of a specific column"""
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT data_type 
                FROM information_schema.columns 
                WHERE table_name = %s AND column_name = %s
            """, [table_name, column_name])
            result = cursor.fetchone()
            return result[0] if result else None
