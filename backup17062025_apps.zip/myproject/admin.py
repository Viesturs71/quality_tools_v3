"""
Custom admin site configuration for the project.
"""
from django.contrib import admin
from django.urls import path
from django.utils.translation import gettext_lazy as _
from django.views.i18n import set_language
from django.contrib.contenttypes.models import ContentType
from django.contrib.auth.models import User, Group, Permission
from django.contrib.auth.admin import UserAdmin, GroupAdmin

class CustomAdminSiteWithLanguageSwitcher(admin.AdminSite):
    site_header = _("Quality Tools Administration")
    site_title = _("Quality Tools Admin")
    index_title = _("System Management")
    
    # Use the standard admin site name for URL compatibility
    name = 'admin'  # Changed from 'quality_tools_admin' to 'admin'
    
    def get_urls(self):
        """Adds a language switching URL to the admin panel."""
        return [path("set_language/", set_language, name="set_language"), *super().get_urls()]

    def get_app_list(self, request, app_label=None):
        """Customizes app ordering in the admin panel."""
        app_list = super().get_app_list(request, app_label)
        custom_order = {
            "accounts": 1,
            "auth": 2,
            "company": 3,
            "equipment": 4,
            "quality_docs": 5,
            "personnel": 6,
            "standards": 7,
        }
        return sorted(app_list, key=lambda x: custom_order.get(x["app_label"], 99))
        
    def each_context(self, request):
        """Add extra context variables to admin templates."""
        context = super().each_context(request)
        context['admin_site_root'] = '/admin/'  # Add the admin site root URL
        return context


# Create an instance of the custom admin site
custom_admin_site = CustomAdminSiteWithLanguageSwitcher()

# Register the auth models with the custom admin site
custom_admin_site.register(User, UserAdmin)
custom_admin_site.register(Group, GroupAdmin)
custom_admin_site.register(Permission)
custom_admin_site.register(ContentType)

# The existing registrations for other models remain unchanged
