from django.core.management.base import BaseCommand
from django.db import connection

class Command(BaseCommand):
    help = 'Set up the database structure for bilingual standard sections'

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS('Setting up bilingual standard sections...'))
        
        # Get existing columns
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = 'standards_standardsection'
            """)
            existing_columns = [row[0] for row in cursor.fetchall()]
        
        # Define all required columns with their data types
        required_columns = {
            'section_number': 'VARCHAR(50)',
            'title': 'VARCHAR(255)',
            'title_en': 'VARCHAR(255)',
            'content': 'TEXT',
            'content_en': 'TEXT',
            'parent_id': 'INTEGER',
            'order': 'INTEGER'
        }
        
        # Add missing columns
        with connection.cursor() as cursor:
            for column, data_type in required_columns.items():
                if column not in existing_columns:
                    self.stdout.write(f'Adding column {column}...')
                    sql = f"ALTER TABLE standards_standardsection ADD COLUMN {column} {data_type}"
                    if column == 'order' and 'order' not in existing_columns:
                        sql += " DEFAULT 0"
                    cursor.execute(sql)
                    self.stdout.write(self.style.SUCCESS(f'Added column {column} successfully!'))
                else:
                    self.stdout.write(f'Column {column} already exists.')
        
        # Ensure parent_id has an index for better performance
        try:
            with connection.cursor() as cursor:
                cursor.execute("""
                    CREATE INDEX IF NOT EXISTS idx_standardsection_parent 
                    ON standards_standardsection(parent_id)
                """)
                self.stdout.write(self.style.SUCCESS('Parent index created or already exists.'))
        except Exception as e:
            self.stdout.write(self.style.WARNING(f'Could not create parent index: {e}'))
        
        self.stdout.write(self.style.SUCCESS('Bilingual standard sections setup completed!'))
