#quality_docs/tests.py
import datetime
from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from quality_docs.models import Company, DocumentType, QualityDocument, ApprovalFlow
from quality_docs.forms import QualityDocumentForm

User = get_user_model()


class QualityDocumentModelTest(TestCase):
    """Test QualityDocument model functionality."""

    @classmethod
    def setUpTestData(cls):
        cls.company = Company.objects.create(name="Test Company", identifier="TC")
        cls.doc_type = DocumentType.objects.create(name="Procedure", identifier="PROC")
        cls.document = QualityDocument.objects.create(
            company=cls.company,
            document_type=cls.doc_type,
            title="Test Document",
            version="v01.00",
            review_date=datetime.date.today() + datetime.timedelta(days=365),
        )

    def test_document_creation(self):
        """Test document creation and identifier generation."""
        self.assertEqual(QualityDocument.objects.count(), 1)
        self.assertIsNotNone(self.document.document_identifier)

    def test_document_string_representation(self):
        """Test the __str__ method."""
        self.assertEqual(
            str(self.document),
            f"{self.document.document_identifier}: {self.document.title} (v{self.document.version})"
        )


class ApprovalFlowTest(TestCase):
    """Test ApprovalFlow functionality."""

    @classmethod
    def setUpTestData(cls):
        cls.company = Company.objects.create(name="Test Company", identifier="TC")
        cls.doc_type = DocumentType.objects.create(name="Instruction", identifier="INST")
        cls.approver = User.objects.create_user(username="approver", password="password")
        cls.document = QualityDocument.objects.create(
            company=cls.company,
            document_type=cls.doc_type,
            title="Approval Document",
            version="v01.01",
            review_date=datetime.date.today() + datetime.timedelta(days=180),
        )
        cls.approval = ApprovalFlow.objects.create(
            document=cls.document,
            approver=cls.approver,
            status="pending",
        )

    def test_approval_creation(self):
        """Test approval flow creation."""
        self.assertEqual(ApprovalFlow.objects.count(), 1)
        self.assertEqual(self.approval.status, "pending")

    def test_approval_status_change(self):
        """Test changing approval status to 'approved'."""
        self.approval.status = "approved"
        self.approval.save()
        self.assertEqual(self.approval.status, "approved")


class QualityDocumentFormTest(TestCase):
    """Test QualityDocumentForm validity."""

    @classmethod
    def setUpTestData(cls):
        cls.company = Company.objects.create(name="Test Company", identifier="TC")
        cls.doc_type = DocumentType.objects.create(name="Order", identifier="ORDER")
        cls.user = User.objects.create_user(username="formuser", password="password")

    def test_valid_form(self):
        """Test form with valid data."""
        form_data = {
            "company": self.company.id,
            "document_type": self.doc_type.id,
            "title": "Form Test",
            "version": "v01.02",
            "review_date": (datetime.date.today() + datetime.timedelta(days=90)).isoformat(),
        }
        form = QualityDocumentForm(data=form_data, user=self.user)
        self.assertTrue(form.is_valid())

    def test_invalid_version_format(self):
        """Test form with invalid version format."""
        form_data = {
            "company": self.company.id,
            "document_type": self.doc_type.id,
            "title": "Invalid Version",
            "version": "01.02",  # Missing 'v' at the beginning
            "review_date": (datetime.date.today() + datetime.timedelta(days=90)).isoformat(),
        }
        form = QualityDocumentForm(data=form_data, user=self.user)
        self.assertFalse(form.is_valid())
        self.assertIn("version", form.errors)


class DocumentViewsTest(TestCase):
    """Test document views."""

    @classmethod
    def setUpTestData(cls):
        cls.client = Client()
        cls.user = User.objects.create_user(username="viewuser", password="password")
        cls.company = Company.objects.create(name="Test Company", identifier="TC")
        cls.doc_type = DocumentType.objects.create(name="Guidelines", identifier="GUIDE")
        cls.document = QualityDocument.objects.create(
            company=cls.company,
            document_type=cls.doc_type,
            title="View Test",
            version="v02.00",
            review_date=datetime.date.today() + datetime.timedelta(days=120),
        )

    def test_document_list_view_requires_login(self):
        """Test that document list is accessible only to logged-in users."""
        response = self.client.get(reverse("quality_docs:document_list"))
        self.assertEqual(response.status_code, 302)  # Redirect to login page

        self.client.login(username="viewuser", password="password")
        response = self.client.get(reverse("quality_docs:document_list"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "View Test")

    def test_document_detail_view(self):
        """Test access to document detail view."""
        self.client.login(username="viewuser", password="password")
        response = self.client.get(reverse("quality_docs:document_detail", args=[self.document.id]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, self.document.title)
        self.client.login(username="viewuser", password="password")
        response = self.client.get(reverse("quality_docs:document_detail", args=[self.document.id]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, self.document.title)
