from django.core.management.base import BaseCommand
from django.db import connection, transaction

class Command(BaseCommand):
    help = 'Reset StandardSection table to fix migration issues'

    def handle(self, *args, **options):
        self.stdout.write('Resetting StandardSection table to fix migration issues...')
        
        try:
            with transaction.atomic():
                # 1. First, clear migration records for the problematic migrations
                with connection.cursor() as cursor:
                    cursor.execute("""
                        DELETE FROM django_migrations 
                        WHERE app = 'standards' AND name LIKE '%standardsection%'
                    """)
                    self.stdout.write(self.style.SUCCESS('Removed problematic migration records'))
                
                # 2. Get existing data if any
                sections_data = []
                try:
                    with connection.cursor() as cursor:
                        cursor.execute("""
                            SELECT id, standard_id, section_number, title, title_user, content, parent_id
                            FROM standards_standardsection
                        """)
                        columns = [col[0] for col in cursor.description]
                        for row in cursor.fetchall():
                            sections_data.append(dict(zip(columns, row)))
                    self.stdout.write(self.style.SUCCESS(f'Backed up {len(sections_data)} section records'))
                except Exception as e:
                    self.stdout.write(self.style.WARNING(f'Could not back up data: {e}'))
                
                # 3. Drop the problematic table
                with connection.cursor() as cursor:
                    cursor.execute("DROP TABLE IF EXISTS standards_standardsection CASCADE")
                    self.stdout.write(self.style.SUCCESS('Dropped problematic table'))
                
                # 4. Create a new table with the correct structure
                with connection.cursor() as cursor:
                    cursor.execute("""
                        CREATE TABLE standards_standardsection (
                            id SERIAL PRIMARY KEY,
                            section_number VARCHAR(50),
                            title TEXT,
                            title_user TEXT,
                            content TEXT,
                            display_order INTEGER DEFAULT 0,
                            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                            parent_id INTEGER REFERENCES standards_standardsection(id) ON DELETE CASCADE NULL,
                            standard_id INTEGER NOT NULL REFERENCES standards_standard(id) ON DELETE CASCADE
                        )
                    """)
                    self.stdout.write(self.style.SUCCESS('Created new table with correct structure'))
                
                # 5. Restore data if we had any
                if sections_data:
                    self.stdout.write('Restoring section data...')
                    with connection.cursor() as cursor:
                        for section in sections_data:
                            # Filter out any fields that don't exist in the new table
                            valid_fields = {'id', 'standard_id', 'section_number', 'title', 
                                           'title_user', 'content', 'parent_id'}
                            section_data = {k: v for k, v in section.items() if k in valid_fields}
                            
                            # Build the SQL dynamically based on available fields
                            fields = list(section_data.keys())
                            placeholders = ['%s'] * len(fields)
                            values = [section_data[field] for field in fields]
                            
                            sql = f"""
                                INSERT INTO standards_standardsection 
                                ({', '.join(fields)})
                                VALUES ({', '.join(placeholders)})
                            """
                            cursor.execute(sql, values)
                    
                    self.stdout.write(self.style.SUCCESS(f'Restored {len(sections_data)} section records'))
                
                # 6. Add an initial migration record so Django thinks the table is migrated
                with connection.cursor() as cursor:
                    cursor.execute("""
                        INSERT INTO django_migrations (app, name, applied)
                        VALUES ('standards', 'manual_fix_for_standardsection', NOW())
                    """)
                    self.stdout.write(self.style.SUCCESS('Added migration record'))
                
                self.stdout.write(self.style.SUCCESS('StandardSection table has been reset successfully!'))
                self.stdout.write(self.style.WARNING('You should now be able to use the admin interface.'))
                self.stdout.write(self.style.WARNING('Do not run migrations for the standards app for now.'))
                
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error resetting table: {str(e)}'))
