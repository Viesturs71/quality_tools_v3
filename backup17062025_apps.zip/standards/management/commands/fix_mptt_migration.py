from django.core.management.base import BaseCommand
from django.db import connection
import logging

class Command(BaseCommand):
    help = 'Fix MPTT migration issues for StandardSection'

    def handle(self, *args, **options):
        self.stdout.write(self.style.WARNING('Starting MPTT migration fix for StandardSection...'))
        
        try:
            # Step 1: Check if the standards_standardsection table exists
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables 
                        WHERE table_name = 'standards_standardsection'
                    )
                """)
                table_exists = cursor.fetchone()[0]
            
            if not table_exists:
                self.stdout.write(self.style.ERROR('Table standards_standardsection does not exist.'))
                return
            
            # Step 2: Fix the migration issue by creating a temporary table with correct structure
            self.stdout.write(self.style.WARNING('Creating a temporary table with correct structure...'))
            
            with connection.cursor() as cursor:
                # Create a temporary table with correct structure
                cursor.execute("""
                    CREATE TABLE standards_standardsection_new (
                        id SERIAL PRIMARY KEY,
                        section_number VARCHAR(50) NOT NULL,
                        title TEXT NOT NULL,
                        title_user TEXT,
                        content TEXT,
                        created_at TIMESTAMP WITH TIME ZONE NOT NULL,
                        updated_at TIMESTAMP WITH TIME ZONE NOT NULL,
                        parent_id INTEGER REFERENCES standards_standardsection(id) ON DELETE CASCADE,
                        standard_id INTEGER NOT NULL REFERENCES standards_standard(id) ON DELETE CASCADE,
                        display_order INTEGER NOT NULL DEFAULT 0,
                        level INTEGER NOT NULL DEFAULT 0,
                        lft INTEGER NOT NULL DEFAULT 0,
                        rght INTEGER NOT NULL DEFAULT 0,
                        tree_id INTEGER NOT NULL DEFAULT 0
                    )
                """)
                
                self.stdout.write(self.style.SUCCESS('Temporary table created.'))
                
                # Copy data from the original table to the temporary table
                # Only copy fields that exist in both tables
                cursor.execute("""
                    SELECT column_name FROM information_schema.columns 
                    WHERE table_name = 'standards_standardsection'
                """)
                existing_columns = [row[0] for row in cursor.fetchall()]
                
                # Construct a list of columns to copy
                safe_columns = []
                for col in ['id', 'section_number', 'title', 'title_user', 'content', 
                           'created_at', 'updated_at', 'parent_id', 'standard_id']:
                    if col in existing_columns:
                        safe_columns.append(col)
                
                # Copy data from original table to temporary table
                columns_str = ', '.join(safe_columns)
                cursor.execute(f"""
                    INSERT INTO standards_standardsection_new ({columns_str})
                    SELECT {columns_str} FROM standards_standardsection
                """)
                
                self.stdout.write(self.style.SUCCESS('Data copied to temporary table.'))
                
                # Drop the original table and rename the temporary table
                cursor.execute("DROP TABLE standards_standardsection CASCADE")
                cursor.execute("ALTER TABLE standards_standardsection_new RENAME TO standards_standardsection")
                
                self.stdout.write(self.style.SUCCESS('Table replaced with corrected structure.'))
                
                # Add MPTT constraints
                cursor.execute("""
                    ALTER TABLE standards_standardsection 
                    ADD CONSTRAINT standards_standardsection_level_check 
                    CHECK (level >= 0)
                """)
                
                cursor.execute("""
                    ALTER TABLE standards_standardsection 
                    ADD CONSTRAINT standards_standardsection_lft_check 
                    CHECK (lft >= 0)
                """)
                
                cursor.execute("""
                    ALTER TABLE standards_standardsection 
                    ADD CONSTRAINT standards_standardsection_rght_check 
                    CHECK (rght >= 0)
                """)
                
                cursor.execute("""
                    ALTER TABLE standards_standardsection 
                    ADD CONSTRAINT standards_standardsection_tree_id_check 
                    CHECK (tree_id >= 0)
                """)
                
                self.stdout.write(self.style.SUCCESS('MPTT constraints added.'))
                
                # Rebuild MPTT structure
                cursor.execute("""
                    UPDATE standards_standardsection
                    SET level = 0, lft = 1, rght = 2, tree_id = id
                    WHERE parent_id IS NULL
                """)
                
                self.stdout.write(self.style.SUCCESS('MPTT structure rebuilt for root nodes.'))
                
            self.stdout.write(self.style.SUCCESS('MPTT migration fix completed successfully!'))
            self.stdout.write(self.style.WARNING('You can now run "python manage.py migrate" to complete the migration.'))
            
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error fixing migration: {str(e)}'))
            logging.exception("Error in fix_mptt_migration command")
