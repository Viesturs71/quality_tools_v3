from django.contrib import admin
from django.urls import path
from django.utils.translation import gettext_lazy as _
from django.views.i18n import set_language
from django_mptt_admin.admin import DjangoMpttAdmin
from django.contrib.auth.models import Permission, User, Group
from django.contrib.auth.admin import UserAdmin, GroupAdmin
from django.contrib.auth.forms import UserCreationForm
from quality_docs.models.documents import DocumentType, QualityDocument
from quality_docs.models.standards import Standard, StandardSection


# Reģistrē nepieciešamos modeļus ar standarta admin
def register_with_custom_admin():
    from accounts.custom_admin import custom_admin_site

    custom_admin_site.register(Permission)


# Pielāgots administrācijas panelis
class CustomAdminSite(admin.AdminSite):
    site_header = _("Pārvaldības sistēmas rīki")
    site_title = _("Administrācija")
    index_title = _("Sistēmas pārvaldība")

    def get_app_list(self, request, app_label=None):
        app_list = super().get_app_list(request, app_label)
        custom_order = {
            "quality_docs": _("Dokumentācija"),
            "methods": _("Metožu vadība"),
            "equipment": _("Iekārtu reģistrs"),
            "staff": _("Personāla vadība"),
            "audits": _("Auditi"),
            "risks": _("Risku vadība"),
            "kpi": _("KPI pārvaldība"),
        }
        return sorted(
            app_list, key=lambda x: custom_order.get(x["app_label"], x["name"])
        )


# Administrācijas panelis ar valodu maiņu
class CustomAdminSiteWithLanguageSwitcher(CustomAdminSite):
    def get_urls(self):
        urls = super().get_urls()
        return [path("set_language/", set_language, name="set_language")] + urls


# Inicializē pielāgoto admin paneli
custom_admin_site = CustomAdminSiteWithLanguageSwitcher(name="custom_admin")


# Dokumentācijas modeļu reģistrācija
class StandardSectionInline(admin.StackedInline):
    model = StandardSection
    extra = 1


class StandardAdmin(admin.ModelAdmin):
    inlines = [StandardSectionInline]
    list_display = ("code", "name", "version")
    search_fields = ("code", "name", "version")
    ordering = ["code"]


class QualityDocumentAdmin(admin.ModelAdmin):
    list_display = ("title", "document_type", "publication_date", "approval_date")
    search_fields = ("title",)
    list_filter = ("document_type", "publication_date")
    ordering = ["-publication_date"]


class StandardSectionAdmin(DjangoMpttAdmin):
    list_display = ("title", "parent", "created_at")
    search_fields = ("title",)
    ordering = ["code"]


# Lietotāju pārvaldība ar pielāgotu admin klasi
class CustomUserAdmin(UserAdmin):
    add_form = UserCreationForm
    list_display = (
        "username",
        "email",
        "first_name",
        "last_name",
        "is_staff",
        "is_active",
    )
    list_filter = ("is_staff", "is_active", "groups")


# Ja `User` modelis nav reģistrēts custom_admin_site, reģistrē to
if User in custom_admin_site._registry:
    custom_admin_site.unregister(User)
custom_admin_site.register(User, CustomUserAdmin)


# Jaunais CustomUserAdmin ar papildu laukiem
@admin.register(User)
class EnhancedCustomUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (
        (_("Uzņēmuma informācija"), {"fields": ("company",)}),
    )
    list_display = (
        "username",
        "email",
        "company",
        "user_document_identifier",
        "is_active",
        "is_staff",
    )
    list_filter = ("company", "is_staff")
    readonly_fields = ("user_document_identifier",)


# Pārējo modeļu reģistrācija
custom_admin_site.register(Standard, StandardAdmin)
custom_admin_site.register(StandardSection, StandardSectionAdmin)
custom_admin_site.register(DocumentType)
custom_admin_site.register(QualityDocument, QualityDocumentAdmin)
custom_admin_site.register(Group, GroupAdmin)
