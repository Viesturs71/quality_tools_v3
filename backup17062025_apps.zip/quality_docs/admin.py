"""
Admin configuration for quality_docs app.
"""
from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from accounts.admin import custom_admin_site

# Import models
from quality_docs.models import (
    QualityDocument, DocumentType, DocumentCategory, DocumentSection,
    DocumentAttachment, DocumentReview, ApprovalFlow, ApprovalStep,
    SignatureRequest, DocumentDistribution, DocumentAcknowledgment
)

# ApprovalStep admin
@admin.register(ApprovalStep)
class ApprovalStepAdmin(admin.ModelAdmin):
    list_display = ('name', 'step_order', 'step_type', 'approver', 'is_required', 'is_complete')
    list_filter = ('step_type', 'is_required', 'is_complete')
    search_fields = ('name',)
    
    def get_queryset(self, request):
        """Optimize queryset to avoid missing fields"""
        qs = super().get_queryset(request)
        return qs.select_related('approver', 'approval_flow').only(
            'id', 'name', 'step_order', 'step_type', 'is_required', 'is_complete',
            'approver__id', 'approver__username', 'approval_flow__id',
            'comments', 'completed_at', 'created_at', 'updated_at'
        )
    
    fieldsets = (
        (None, {
            'fields': ('name', 'step_order', 'step_type', 'approver', 'approval_flow')
        }),
        ('Status', {
            'fields': ('is_required', 'is_complete', 'comments', 'completed_at')
        }),
    )

# Register other models with basic admin interfaces
# Only register with custom_admin_site to avoid duplicate registrations
class ApprovalFlowAdmin(admin.ModelAdmin):
    list_display = ('name', 'document', 'created_at')
    search_fields = ('name',)

class DocumentCategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('name', 'description')

class DocumentSectionAdmin(admin.ModelAdmin):
    list_display = ('name', 'identifier', 'parent')
    search_fields = ('name', 'identifier')

class DocumentTypeAdmin(admin.ModelAdmin):
    list_display = ('name', 'abbreviation', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('name', 'abbreviation', 'description')

class QualityDocumentAdmin(admin.ModelAdmin):
    list_display = ('title', 'document_number', 'document_type')
    list_filter = ('document_type',)
    search_fields = ('title', 'document_number', 'keywords')
    
    def get_queryset(self, request):
        """Optimize queryset to avoid issues with missing fields"""
        qs = super().get_queryset(request)
        return qs.select_related('document_type').only(
            'id', 'title', 'document_number', 
            'document_type__id', 'document_type__name'
        )
    
    # Override ordering to avoid using created_at
    ordering = ('document_number',)
    
    fieldsets = (
        (None, {
            'fields': ('title', 'document_number', 'document_type')
        }),
        ('Document Details', {
            'fields': ('file', 'keywords', 'is_template')
        }),
        ('Dates', {
            'fields': ('effective_date', 'expiry_date', 'review_date')
        }),
    )

# Register all models with the custom admin site
custom_admin_site.register(ApprovalFlow, ApprovalFlowAdmin)
custom_admin_site.register(ApprovalStep, ApprovalStepAdmin)
custom_admin_site.register(DocumentCategory, DocumentCategoryAdmin)
custom_admin_site.register(DocumentSection, DocumentSectionAdmin)
custom_admin_site.register(DocumentType, DocumentTypeAdmin)
custom_admin_site.register(QualityDocument, QualityDocumentAdmin)
# custom_admin_site.register(WorkflowRuleSet)
# custom_admin_site.register(WorkflowTemplate)
# custom_admin_site.register(Document)
# custom_admin_site.register(DocumentReview)
# custom_admin_site.register(DocumentDistribution)
# custom_admin_site.register(DocumentAttachment)
# custom_admin_site.register(DocumentAcknowledgment)
# custom_admin_site.register(WorkflowNotification)
# custom_admin_site.register(WorkflowAssignment)
# custom_admin_site.register(SignatureRequest)

# Admin site customization
custom_admin_site.site_header = _("Quality Tools Administration")
custom_admin_site.site_title = _("Quality Tools Admin")
custom_admin_site.index_title = _("Welcome to Quality Tools Administration")