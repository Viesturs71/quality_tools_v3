"""
Quality documents models initialization.
This file provides backward compatibility for existing imports.
"""
# Import all models directly from document.py since all models are defined there
from .document import (
    DocumentType, DocumentCategory, DocumentSection, QualityDocument,
    ApprovalFlow, ApprovalStep, DocumentReview, DocumentAttachment,
    WorkflowRuleSet, WorkflowTemplate, WorkflowAssignment, WorkflowNotification,
    SignatureRequest, DocumentDistribution, DocumentAcknowledgment, Document
)

# Export all models
__all__ = [
    'DocumentType', 'DocumentCategory', 'DocumentSection', 'QualityDocument',
    'ApprovalFlow', 'ApprovalStep', 'DocumentReview', 'DocumentAttachment',
    'WorkflowRuleSet', 'WorkflowTemplate', 'WorkflowAssignment', 'WorkflowNotification',
    'SignatureRequest', 'DocumentDistribution', 'DocumentAcknowledgment', 'Document'
]
