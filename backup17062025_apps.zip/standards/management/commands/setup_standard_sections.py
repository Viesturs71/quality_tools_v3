from django.core.management.base import BaseCommand
from django.db import connection

class Command(BaseCommand):
    help = 'Set up the database schema for StandardSection with bilingual support'

    def handle(self, *args, **options):
        self.stdout.write('Setting up StandardSection database schema...')
        
        # Check if table exists
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_name = 'standards_standardsection'
                )
            """)
            table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            self.stdout.write(self.style.WARNING(
                'Table standards_standardsection does not exist. '
                'Run migrations first: python manage.py migrate standards'
            ))
            return
        
        # Get existing columns
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = 'standards_standardsection'
            """)
            existing_columns = [row[0] for row in cursor.fetchall()]
            
            self.stdout.write(f'Found columns: {", ".join(existing_columns)}')
        
        # Remove problematic order column if it exists
        if 'order' in existing_columns:
            self.stdout.write('Removing problematic order column...')
            try:
                with connection.cursor() as cursor:
                    cursor.execute('ALTER TABLE standards_standardsection DROP COLUMN "order"')
                self.stdout.write(self.style.SUCCESS('Removed order column'))
            except Exception as e:
                self.stdout.write(self.style.ERROR(f'Error removing order column: {e}'))
        
        # Define required columns for bilingual content
        required_columns = {
            'section_number': 'VARCHAR(50)',
            'title': 'VARCHAR(255)',
            'content': 'TEXT',
            'title_en': 'VARCHAR(255)',
            'content_en': 'TEXT',
        }
        
        # Add missing columns
        added_columns = []
        for column, data_type in required_columns.items():
            if column not in existing_columns:
                self.stdout.write(f'Adding column {column}...')
                try:
                    with connection.cursor() as cursor:
                        cursor.execute(f'ALTER TABLE standards_standardsection ADD COLUMN {column} {data_type}')
                    added_columns.append(column)
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error adding column {column}: {e}'))
        
        if added_columns:
            self.stdout.write(self.style.SUCCESS(f'Added columns: {", ".join(added_columns)}'))
        else:
            self.stdout.write(self.style.SUCCESS('All required columns already exist'))
        
        self.stdout.write(self.style.SUCCESS('StandardSection schema setup complete!'))
