from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group, Permission
from django.contrib.contenttypes.models import ContentType
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Izveido noklusējuma grupas un piešķir tām tiesības."

    def handle(self, *args, **kwargs):
        """Funkcija, kas izveido noklusējuma grupas un pievieno tām tiesības."""

        # Saņem lietotāja modeli
        User = get_user_model()
        app_label = User._meta.app_label
        model_name = User._meta.model_name

        admin_group, created = Group.objects.get_or_create(name="Administrators")
        editor_group, created = Group.objects.get_or_create(name="Editors")
        viewer_group, created = Group.objects.get_or_create(name="Viewers")

        try:
            # Meklējam ContentType pēc faktiskās aplikācijas un modeļa nosaukuma
            user_content_type = ContentType.objects.get(
                app_label=app_label, model=model_name
            )

            add_user_permission = Permission.objects.get(
                codename="add_user", content_type=user_content_type
            )
            change_user_permission = Permission.objects.get(
                codename="change_user", content_type=user_content_type
            )

            admin_group.permissions.add(add_user_permission, change_user_permission)
            editor_group.permissions.add(change_user_permission)

            self.stdout.write(
                self.style.SUCCESS(
                    "✅ Noklusējuma grupas un tiesības veiksmīgi izveidotas!"
                )
            )
        except ContentType.DoesNotExist:
            self.stdout.write(
                self.style.WARNING(
                    f"⚠️ ContentType '{model_name}' vēl nav pieejams. Pārliecinieties, ka migrācijas ir pielietotas!"
                )
            )
