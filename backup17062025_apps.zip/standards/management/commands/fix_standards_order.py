from django.core.management.base import BaseCommand
from django.db import connection

class Command(BaseCommand):
    help = 'Fix order-related issues in the standards database tables'

    def handle(self, *args, **options):
        self.stdout.write('Fixing order column issues...')
        
        # Check if the StandardSection table exists and has an order column
        self.fix_standard_section_table()
        
        # Check if the StandardSubsection table exists
        self.fix_standard_subsection_table()
        
        self.stdout.write(self.style.SUCCESS('Order column issues fixed!'))
    
    def fix_standard_section_table(self):
        """Fix StandardSection table"""
        self.stdout.write('Checking StandardSection table...')
        
        # Check if table exists
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_name = 'standards_standardsection'
                )
            """)
            table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            self.stdout.write(self.style.WARNING('StandardSection table does not exist'))
            return
        
        # Check if 'order' column exists
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.columns 
                    WHERE table_name = 'standards_standardsection' 
                    AND column_name = 'order'
                )
            """)
            order_exists = cursor.fetchone()[0]
        
        if order_exists:
            self.stdout.write('Dropping "order" column from StandardSection...')
            try:
                with connection.cursor() as cursor:
                    cursor.execute('ALTER TABLE standards_standardsection DROP COLUMN "order"')
                self.stdout.write(self.style.SUCCESS('Dropped "order" column from StandardSection'))
            except Exception as e:
                self.stdout.write(self.style.ERROR(f'Error dropping column: {e}'))
    
    def fix_standard_subsection_table(self):
        """Fix StandardSubsection table"""
        self.stdout.write('Checking StandardSubsection table...')
        
        # Check if table exists
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_name = 'standards_standardsubsection'
                )
            """)
            table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            self.stdout.write(self.style.WARNING('StandardSubsection table does not exist'))
            return
        
        # Make sure 'order' is renamed to 'sort_order' if it exists
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.columns 
                    WHERE table_name = 'standards_standardsubsection' 
                    AND column_name = 'order'
                )
            """)
            order_exists = cursor.fetchone()[0]
        
        if order_exists:
            # Check if sort_order exists before renaming
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT EXISTS (
                        SELECT FROM information_schema.columns 
                        WHERE table_name = 'standards_standardsubsection' 
                        AND column_name = 'sort_order'
                    )
                """)
                sort_order_exists = cursor.fetchone()[0]
            
            if not sort_order_exists:
                self.stdout.write('Renaming "order" column to "sort_order"...')
                try:
                    with connection.cursor() as cursor:
                        cursor.execute('ALTER TABLE standards_standardsubsection RENAME COLUMN "order" TO "sort_order"')
                    self.stdout.write(self.style.SUCCESS('Renamed "order" column to "sort_order"'))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error renaming column: {e}'))
            else:
                self.stdout.write('Dropping "order" column since "sort_order" already exists...')
                try:
                    with connection.cursor() as cursor:
                        cursor.execute('ALTER TABLE standards_standardsubsection DROP COLUMN "order"')
                    self.stdout.write(self.style.SUCCESS('Dropped "order" column'))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error dropping column: {e}'))
