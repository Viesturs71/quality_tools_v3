"""
Admin configuration for personnel app
"""
from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from .models import Employee, Qualification, Training, EmployeeRecord, Education
from accounts.admin import custom_admin_site

class EmployeeRecordInline(admin.TabularInline):
    model = EmployeeRecord
    extra = 1


@admin.register(Employee, site=custom_admin_site)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ['first_name', 'last_name', 'email']
    search_fields = ['first_name', 'last_name', 'email']
    fieldsets = (
        (None, {
            'fields': ('first_name', 'last_name', 'user')
        }),
        (_('Employment Information'), {
            'fields': ('position', 'hire_date')
        }),
        (_('Contact Information'), {
            'fields': ('email',)
        }),
    )
    
    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        # Only add department field if we've fixed the database
        from django.db import connection
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.columns 
                    WHERE table_name = 'company_department' 
                    AND column_name = 'is_active'
                );
            """)
            has_is_active = cursor.fetchone()[0]
        
        if has_is_active and 'department' not in form.base_fields:
            # Add department field if it's safe to use
            from django import forms
            from company.models import Department
            form.base_fields['department'] = forms.ModelChoiceField(
                queryset=Department.objects.all(),
                required=False,
                label=_('Department')
            )
            
        return form
    
    def get_queryset(self, request):
        """Optimize queryset to avoid issues with missing fields"""
        return super().get_queryset(request).select_related('user')


@admin.register(Qualification, site=custom_admin_site)
class QualificationAdmin(admin.ModelAdmin):
    list_display = ['employee', 'qualification_type', 'issue_date', 'expiry_date']
    list_filter = ['qualification_type']
    search_fields = ['employee__first_name', 'employee__last_name', 'qualification_type']


@admin.register(Training, site=custom_admin_site)
class TrainingAdmin(admin.ModelAdmin):
    list_display = ['employee', 'training_name', 'start_date', 'end_date', 'status']
    list_filter = ['status']
    search_fields = ['employee__first_name', 'employee__last_name', 'training_name']


@admin.register(EmployeeRecord, site=custom_admin_site)
class EmployeeRecordAdmin(admin.ModelAdmin):
    list_display = ['employee', 'record_type', 'title', 'issue_date', 'is_confidential']
    list_filter = ['record_type', 'is_confidential']
    search_fields = ['employee__first_name', 'employee__last_name', 'title']
    fieldsets = (
        (None, {
            'fields': ('employee', 'record_type', 'title', 'description')
        }),
        (_('Document Information'), {
            'fields': ('issue_date', 'expiry_date', 'document')
        }),
        (_('Security'), {
            'fields': ('is_confidential',)
        }),
        (_('Additional Information'), {
            'fields': ('notes',)
        }),
    )


@admin.register(Education, site=custom_admin_site)
class EducationAdmin(admin.ModelAdmin):
    list_display = ['employee', 'level', 'institution', 'degree', 'is_completed']
    list_filter = ['level', 'is_completed']
    search_fields = ['employee__first_name', 'employee__last_name', 'institution', 'degree']
    fieldsets = (
        (None, {
            'fields': ('employee', 'level', 'institution')
        }),
        (_('Degree Information'), {
            'fields': ('field_of_study', 'degree', 'start_date', 'end_date', 'is_completed')
        }),
        (_('Documentation'), {
            'fields': ('description', 'document')
        }),
    )


