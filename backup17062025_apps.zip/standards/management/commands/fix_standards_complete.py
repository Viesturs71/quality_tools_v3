from django.core.management.base import BaseCommand
from django.core.management import call_command

class Command(BaseCommand):
    help = 'Complete fix for standards app - fixes models and applies migrations'

    def handle(self, *args, **options):
        self.stdout.write(self.style.WARNING('Starting complete standards app fix...'))
        
        # Step 1: Fix the Standard model
        self.stdout.write('Step 1: Fixing Standard model...')
        call_command('fix_standard_model')
        
        # Step 2: Fix the StandardSection model
        self.stdout.write('Step 2: Fixing StandardSection model...')
        call_command('fix_standards_db')
        
        # Step 3: Mark migrations as applied
        self.stdout.write('Step 3: Applying migrations...')
        call_command('apply_standards_migrations')
        
        self.stdout.write(self.style.SUCCESS('All fixes applied successfully!'))
        self.stdout.write(self.style.SUCCESS('Your database should now be consistent with the models.'))
