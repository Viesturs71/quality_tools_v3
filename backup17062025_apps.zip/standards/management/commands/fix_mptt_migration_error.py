from django.core.management.base import BaseCommand
from django.db import connection

class Command(BaseCommand):
    help = 'Fix MPTT migration errors for StandardSection'

    def handle(self, *args, **options):
        self.stdout.write('Fixing MPTT migration errors for StandardSection...')
        
        # Check if table exists
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_name = 'standards_standardsection'
                )
            """)
            table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            self.stdout.write(self.style.ERROR('Table standards_standardsection does not exist!'))
            return
        
        # Get existing columns
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT column_name, data_type 
                FROM information_schema.columns 
                WHERE table_name = 'standards_standardsection'
            """)
            columns = {row[0]: row[1] for row in cursor.fetchall()}
        
        self.stdout.write(f'Found columns: {", ".join(columns.keys())}')
        
        # Fix MPTT fields
        mptt_fields = ['level', 'lft', 'rght', 'tree_id']
        for field in mptt_fields:
            if field in columns:
                if columns[field] != 'integer':
                    self.stdout.write(f'Field {field} has wrong type: {columns[field]}. Fixing...')
                    try:
                        # Create a new integer column with correct name
                        new_col_name = f"new_{field}"
                        with connection.cursor() as cursor:
                            # Add new column with correct type
                            cursor.execute(f"""
                                ALTER TABLE standards_standardsection 
                                ADD COLUMN {new_col_name} INTEGER DEFAULT 0
                            """)
                            
                            # Drop old column and rename new one to original name
                            cursor.execute(f"""
                                ALTER TABLE standards_standardsection 
                                DROP COLUMN {field}
                            """)
                            
                            cursor.execute(f"""
                                ALTER TABLE standards_standardsection 
                                RENAME COLUMN {new_col_name} TO {field}
                            """)
                        
                        self.stdout.write(self.style.SUCCESS(f'Fixed {field} field'))
                    except Exception as e:
                        self.stdout.write(self.style.ERROR(f'Error fixing {field}: {str(e)}'))
            else:
                # Add missing MPTT field
                self.stdout.write(f'Adding missing MPTT field: {field}')
                try:
                    with connection.cursor() as cursor:
                        cursor.execute(f"""
                            ALTER TABLE standards_standardsection 
                            ADD COLUMN {field} INTEGER DEFAULT 0
                        """)
                    self.stdout.write(self.style.SUCCESS(f'Added {field} field'))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error adding {field}: {str(e)}'))
        
        # Now add other required fields if missing
        required_fields = {
            'section_number': 'VARCHAR(50)',
            'title': 'TEXT',
            'title_user': 'TEXT',
            'content': 'TEXT',
            'display_order': 'INTEGER',
            'parent_id': 'INTEGER',
            'standard_id': 'INTEGER'
        }
        
        for field, field_type in required_fields.items():
            if field not in columns:
                self.stdout.write(f'Adding missing field: {field}')
                try:
                    with connection.cursor() as cursor:
                        cursor.execute(f"""
                            ALTER TABLE standards_standardsection 
                            ADD COLUMN {field} {field_type} NULL
                        """)
                    self.stdout.write(self.style.SUCCESS(f'Added {field} field'))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error adding {field}: {str(e)}'))
        
        # Fix schema
        try:
            self.stdout.write('Fixing schema issues with Django migrations table...')
            with connection.cursor() as cursor:
                # Delete problematic migrations
                cursor.execute("""
                    DELETE FROM django_migrations 
                    WHERE app = 'standards' AND name LIKE '%mptt%'
                """)
                
                # Set the app to have only applied the initial migration
                cursor.execute("""
                    DELETE FROM django_migrations 
                    WHERE app = 'standards' AND name != '0001_initial'
                """)
                
                # If no initial migration exists, add one
                cursor.execute("""
                    SELECT COUNT(*) FROM django_migrations 
                    WHERE app = 'standards' AND name = '0001_initial'
                """)
                has_initial = cursor.fetchone()[0]
                
                if not has_initial:
                    cursor.execute("""
                        INSERT INTO django_migrations (app, name, applied) 
                        VALUES ('standards', '0001_initial', NOW())
                    """)
                    
            self.stdout.write(self.style.SUCCESS('Fixed migration records'))
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error fixing migration records: {str(e)}'))
        
        self.stdout.write(self.style.SUCCESS('MPTT migration fix completed!'))
        self.stdout.write(self.style.WARNING('Now try running migrations again with:'))
        self.stdout.write('python manage.py makemigrations standards')
        self.stdout.write('python manage.py migrate standards')
