from django.core.management.base import BaseCommand
from django.db import connection, transaction

class Command(BaseCommand):
    help = 'Fix StandardSubsection table issues'

    def handle(self, *args, **options):
        self.stdout.write(self.style.WARNING('Starting fix for StandardSubsection table...'))
        
        try:
            with transaction.atomic():
                # Check if the table exists
                with connection.cursor() as cursor:
                    cursor.execute("""
                        SELECT EXISTS (
                            SELECT FROM information_schema.tables 
                            WHERE table_name = 'standards_standardsubsection'
                        )
                    """)
                    table_exists = cursor.fetchone()[0]
                
                if not table_exists:
                    # Create the table if it doesn't exist
                    self.stdout.write('Creating standards_standardsubsection table...')
                    with connection.cursor() as cursor:
                        cursor.execute("""
                            CREATE TABLE standards_standardsubsection (
                                id SERIAL PRIMARY KEY,
                                subsection_number VARCHAR(20) NOT NULL,
                                title VARCHAR(255) NOT NULL,
                                content TEXT,
                                "order" INTEGER NOT NULL DEFAULT 0,
                                created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
                                updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
                                section_id INTEGER NOT NULL REFERENCES standards_standardsection(id) ON DELETE CASCADE
                            )
                        """)
                    self.stdout.write(self.style.SUCCESS('Created standards_standardsubsection table'))
                
                self.stdout.write(self.style.SUCCESS('StandardSubsection table fix completed!'))
                
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error: {str(e)}'))
