from django.core.management.base import BaseCommand
from django.db import connection, transaction

class Command(BaseCommand):
    help = 'Fix database schema for standards app'

    def handle(self, *args, **options):
        self.stdout.write(self.style.WARNING('Starting database fix for StandardSection...'))
        
        try:
            with transaction.atomic():
                # 1. Backup existing data
                sections_data = []
                table_exists = self.check_table_exists('standards_standardsection')
                
                if table_exists:
                    # Get columns that exist in the table
                    existing_columns = self.get_table_columns('standards_standardsection')
                    
                    # Backup data if possible
                    if 'id' in existing_columns and 'section_number' in existing_columns:
                        self.stdout.write('Backing up existing data...')
                        
                        # Build a safe query with only columns we know exist
                        safe_columns = [
                            col for col in ['id', 'standard_id', 'section_number', 'title', 
                                           'title_user', 'content', 'parent_id', 'display_order']
                            if col in existing_columns
                        ]
                        
                        if safe_columns:
                            # Fetch existing data
                            columns_str = ', '.join(safe_columns)
                            with connection.cursor() as cursor:
                                cursor.execute(f"SELECT {columns_str} FROM standards_standardsection")
                                rows = cursor.fetchall()
                                columns = [col[0] for col in cursor.description]
                                
                                for row in rows:
                                    sections_data.append(dict(zip(columns, row)))
                            
                            self.stdout.write(f'Backed up {len(sections_data)} records')
                
                # 2. Drop existing table
                if table_exists:
                    self.stdout.write('Dropping existing table...')
                    with connection.cursor() as cursor:
                        cursor.execute("DROP TABLE IF EXISTS standards_standardsection CASCADE")
                
                # 3. Create new table with correct structure
                self.stdout.write('Creating new table with correct structure...')
                with connection.cursor() as cursor:
                    cursor.execute("""
                        CREATE TABLE standards_standardsection (
                            id SERIAL PRIMARY KEY,
                            section_number VARCHAR(50),
                            title TEXT,
                            title_user TEXT,
                            content TEXT,
                            display_order INTEGER DEFAULT 0,
                            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                            parent_id INTEGER REFERENCES standards_standardsection(id) ON DELETE CASCADE NULL,
                            standard_id INTEGER NOT NULL REFERENCES standards_standard(id) ON DELETE CASCADE
                        )
                    """)
                
                # 4. Restore data
                if sections_data:
                    self.stdout.write('Restoring data...')
                    for section in sections_data:
                        if 'standard_id' not in section or section['standard_id'] is None:
                            continue
                            
                        fields = list(section.keys())
                        placeholders = ['%s'] * len(fields)
                        values = [section[field] for field in fields]
                        
                        sql = f"""
                            INSERT INTO standards_standardsection 
                            ({', '.join(fields)})
                            VALUES ({', '.join(placeholders)})
                        """
                        with connection.cursor() as cursor:
                            cursor.execute(sql, values)
                
                # 5. Fix django_migrations
                self.stdout.write('Fixing migration records...')
                with connection.cursor() as cursor:
                    cursor.execute("""
                        DELETE FROM django_migrations 
                        WHERE app = 'standards' AND name LIKE '%mptt%'
                    """)
                    
                    # Add fake migration record
                    cursor.execute("""
                        INSERT INTO django_migrations (app, name, applied)
                        VALUES ('standards', 'fix_completed_manually', NOW())
                    """)
                
                self.stdout.write(self.style.SUCCESS('StandardSection table fixed successfully!'))
                
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error: {str(e)}'))
    
    def check_table_exists(self, table_name):
        with connection.cursor() as cursor:
            cursor.execute(f"""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_name = %s
                )
            """, [table_name])
            return cursor.fetchone()[0]
    
    def get_table_columns(self, table_name):
        with connection.cursor() as cursor:
            cursor.execute(f"""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = %s
            """, [table_name])
            return [row[0] for row in cursor.fetchall()]
