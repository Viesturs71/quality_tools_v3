from django.core.management.base import BaseCommand
from django.db import connection

class Command(BaseCommand):
    help = 'Add dual title fields to StandardSection table'

    def handle(self, *args, **options):
        self.stdout.write('Adding dual title fields to StandardSection...')
        
        # Check if table exists
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_name = 'standards_standardsection'
                )
            """)
            table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            self.stdout.write(self.style.ERROR('Table standards_standardsection does not exist!'))
            self.stdout.write('Run migrations first: python manage.py migrate standards')
            return
            
        # Get existing columns
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = 'standards_standardsection'
            """)
            existing_columns = [row[0] for row in cursor.fetchall()]
            
        self.stdout.write(f'Found columns: {", ".join(existing_columns)}')
        
        # Add dual title columns
        dual_title_columns = {
            'title': 'TEXT NULL',         # Original section title
            'title_user': 'TEXT NULL',    # User-defined section title
            'content': 'TEXT NULL',       # Content
        }
        
        # Convert any existing VARCHAR fields to TEXT
        for column in existing_columns:
            if column in ['title']:
                try:
                    with connection.cursor() as cursor:
                        cursor.execute(f"""
                            ALTER TABLE standards_standardsection
                            ALTER COLUMN {column} TYPE TEXT
                        """)
                    self.stdout.write(self.style.SUCCESS(f'Converted {column} to TEXT type'))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error converting {column}: {e}'))
        
        # Add missing columns
        added_columns = []
        for column, data_type in dual_title_columns.items():
            if column not in existing_columns:
                self.stdout.write(f'Adding {column} column...')
                try:
                    with connection.cursor() as cursor:
                        cursor.execute(f"""
                            ALTER TABLE standards_standardsection 
                            ADD COLUMN {column} {data_type}
                        """)
                    added_columns.append(column)
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error adding {column}: {e}'))
            else:
                self.stdout.write(f'{column} already exists')
        
        if added_columns:
            self.stdout.write(self.style.SUCCESS(f'Added {len(added_columns)} columns: {", ".join(added_columns)}'))
            self.stdout.write(self.style.SUCCESS('Restart your Django server to use the new fields.'))
        else:
            self.stdout.write(self.style.SUCCESS('All dual title columns already exist.'))
