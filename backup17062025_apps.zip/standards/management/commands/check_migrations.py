from django.core.management.base import BaseCommand
from django.db import connection
import os
import re

class Command(BaseCommand):
    help = 'Check migration status and provide recommendations'

    def handle(self, *args, **options):
        self.stdout.write(self.style.NOTICE('Checking migration status for standards app...'))
        
        # 1. Check database migration state
        applied_migrations = self.get_applied_migrations()
        self.stdout.write(f"Applied migrations in database: {', '.join(applied_migrations) if applied_migrations else 'None'}")
        
        # 2. Check migration files on disk
        migration_files = self.get_migration_files()
        self.stdout.write(f"Migration files on disk: {', '.join(migration_files) if migration_files else 'None'}")
        
        # 3. Check for missing files
        missing_files = [m for m in applied_migrations if m not in migration_files]
        if missing_files:
            self.stdout.write(self.style.ERROR(f"⚠️ Missing migration files that are in the database: {', '.join(missing_files)}"))
            self.stdout.write(self.style.WARNING("This can cause 'NodeNotFoundError' when trying to run the server."))
            self.stdout.write(self.style.NOTICE("Recommended action: Create these missing migration files."))
        
        # 4. Check for unapplied migrations
        unapplied = [m for m in migration_files if m not in applied_migrations]
        if unapplied:
            self.stdout.write(self.style.WARNING(f"⚠️ Unapplied migrations (on disk but not in database): {', '.join(unapplied)}"))
            self.stdout.write(self.style.NOTICE("Recommended action: Run 'python manage.py migrate standards'."))
        
        # 5. Check for potential dependency issues
        dependency_issues = self.check_dependencies(migration_files)
        if dependency_issues:
            self.stdout.write(self.style.ERROR("⚠️ Potential dependency issues:"))
            for issue in dependency_issues:
                self.stdout.write(f"  - {issue}")
            self.stdout.write(self.style.NOTICE("Recommended action: Fix dependencies in migration files or run 'fix_standards_migrations'."))
        
        # 6. Provide a summary
        if not (missing_files or unapplied or dependency_issues):
            self.stdout.write(self.style.SUCCESS("✅ All migrations appear to be in sync. No issues detected."))
        else:
            self.stdout.write(self.style.WARNING("\nTo fix all issues automatically, run: python manage.py fix_standards_migrations"))
    
    def get_applied_migrations(self):
        """Get list of applied migrations from the database"""
        try:
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT name FROM django_migrations 
                    WHERE app = 'standards'
                    ORDER BY id
                """)
                return [row[0] for row in cursor.fetchall()]
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"Error checking database: {str(e)}"))
            return []
    
    def get_migration_files(self):
        """Get list of migration files from disk"""
        try:
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            migrations_dir = os.path.join(base_dir, 'migrations')
            
            migration_files = []
            if os.path.exists(migrations_dir):
                for filename in os.listdir(migrations_dir):
                    # Skip __init__.py and non-python files
                    if filename == '__init__.py' or not filename.endswith('.py'):
                        continue
                    
                    # Extract migration name (without .py extension)
                    migration_files.append(os.path.splitext(filename)[0])
            
            return sorted(migration_files)
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"Error checking migration files: {str(e)}"))
            return []
    
    def check_dependencies(self, migration_files):
        """Check for potential dependency issues in migration files"""
        issues = []
        
        try:
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            migrations_dir = os.path.join(base_dir, 'migrations')
            
            # Pattern to extract dependencies
            dependency_pattern = r"dependencies\s*=\s*\[\s*\(?\s*['\"]([\w_]+)['\"],\s*['\"]([\w_]+)['\"]"
            
            for filename in migration_files:
                filepath = os.path.join(migrations_dir, f"{filename}.py")
                if not os.path.exists(filepath):
                    continue
                
                with open(filepath, 'r') as f:
                    content = f.read()
                
                # Find dependencies
                matches = re.findall(dependency_pattern, content)
                for app, migration in matches:
                    if app == 'standards' and migration not in migration_files:
                        issues.append(f"Migration '{filename}' depends on non-existent '{migration}'")
            
            return issues
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"Error checking dependencies: {str(e)}"))
            return ["Unable to check dependencies: " + str(e)]
