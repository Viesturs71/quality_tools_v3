from django.contrib import admin
from django.contrib.admin import AdminSite
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import Group, Permission
from django.urls import reverse
from django.utils.html import format_html
from django.utils.translation import gettext_lazy as _

# Models imports
from accounts.models import CustomUser
from quality_docs.models import (
    DocumentSection,
    DocumentType,
    QualityDocument,
    Standard,
    StandardSection,
    Company,
)
from methods.models.metozu_registrs import MetozuRegistrs


# Define StandardAdmin first
class StandardAdmin(admin.ModelAdmin):
    list_display = ["name", "created_at", "updated_at"]
    search_fields = ["name"]
    ordering = ["-created_at"]


class CustomAdminSite(AdminSite):
    """Custom admin site with enhanced menu structure"""

    site_header = "Pārvaldības sistēmas rīki"
    site_title = "Administrācijas panelis"
    index_title = "Sistēmas pārvaldība"

    def get_app_list(self, request, app_label=None):
        """
        Pielāgota app_list, kas izslēdz noklusētās lietotnes un
        manuāli ievieto nepieciešamās sadaļas
        """
        app_list = [
            app
            for app in super().get_app_list(request, app_label)
            if app["app_label"] not in ["auth", "quality_docs", "accounts"]
        ]

        # Auth section
        try:
            user_url = reverse("admin:accounts_customuser_changelist")
            user_add_url = reverse("admin:accounts_customuser_add")
            group_url = reverse("admin:auth_group_changelist")
            group_add_url = reverse("admin:auth_group_add")
            perm_url = reverse("admin:auth_permission_changelist")
            perm_add_url = reverse("admin:auth_permission_add")
        except Exception:
            user_url, user_add_url = (
                "/admin/accounts/customuser/",
                "/admin/accounts/customuser/add/",
            )
            group_url, group_add_url = "/admin/auth/group/", "/admin/auth/group/add/"
            perm_url, perm_add_url = (
                "/admin/auth/permission/",
                "/admin/auth/permission/add/",
            )

        auth_app = {
            "name": _("Autentifikācija un autorizācija"),
            "app_label": "auth_custom",
            "app_url": "",
            "models": [
                {
                    "name": _("👤 Lietotāji"),
                    "admin_url": user_url,
                    "add_url": user_add_url,
                },
                {
                    "name": _("👥 Grupas"),
                    "admin_url": group_url,
                    "add_url": group_add_url,
                },
                {
                    "name": _("🔓 Tiesības"),
                    "admin_url": perm_url,
                    "add_url": perm_add_url,
                },
            ],
        }

        # Documentation section
        doc_app = {
            "name": _("Dokumentācija"),
            "app_label": "quality_docs_custom",
            "app_url": "",
            "models": [
                {
                    "name": format_html("<b>📚 Standartu vadība</b>"),
                    "admin_url": None,
                    "add_url": None,
                },
                {
                    "name": _("📁 Standartu reģistrācija"),
                    "admin_url": "/admin/quality_docs/qualitystandard/",
                    "add_url": "/admin/quality_docs/qualitystandard/add/",
                },
                {
                    "name": _("📑 Standarta sadaļas"),
                    "admin_url": "/admin/quality_docs/standardsection/",
                    "add_url": "/admin/quality_docs/standardsection/add/",
                },
                {
                    "name": format_html("<br><b>📄 Uzņēmuma dokumentu vadība</b>"),
                    "admin_url": None,
                    "add_url": None,
                },
                {
                    "name": _("📝 Dokumentu reģistrs"),
                    "admin_url": "/admin/quality_docs/qualitydocument/",
                    "add_url": "/admin/quality_docs/qualitydocument/add/",
                },
                {
                    "name": _("🗂 Dokumentu veidi"),
                    "admin_url": "/admin/quality_docs/documenttype/",
                    "add_url": "/admin/quality_docs/documenttype/add/",
                },
                {
                    "name": format_html("<br><b>🔬 Metodes</b>"),
                    "admin_url": None,
                    "add_url": None,
                },
                {
                    "name": _("🔬 Metožu reģistrs"),
                    "admin_url": "/admin/quality_docs/metozuregistrs/",
                    "add_url": "/admin/quality_docs/metozuregistrs/add/",
                },
                {
                    "name": _("📚 ĀKK metodei"),
                    "admin_url": "/admin/quality_docs/akkregistrs/",
                    "add_url": "/admin/quality_docs/akkregistrs/add/",
                },
            ],
        }

        # Add sections to app_list
        app_list.insert(0, auth_app)
        app_list.insert(1, doc_app)
        return app_list


# Initialize admin site
admin_site = CustomAdminSite(name="admin")

# Register all models
admin_site.register(CustomUser, UserAdmin)
admin_site.register(Group)
admin_site.register(Permission)
admin_site.register(Standard, StandardAdmin)
admin_site.register(StandardSection)
admin_site.register(DocumentType)
admin_site.register(QualityDocument)
admin_site.register(DocumentSection)
admin_site.register(MetozuRegistrs)
admin_site.register(Company)
custom_admin_site = admin_site
