from django.core.management.base import BaseCommand
from django.db import connection
import logging

class Command(BaseCommand):
    help = 'Fix the StandardSection table schema'

    def handle(self, *args, **options):
        self.stdout.write('Checking StandardSection table schema...')
        
        # Step 1: Check if the table exists
        if not self.table_exists('standards_standardsection'):
            self.stdout.write(self.style.WARNING(
                'Table standards_standardsection does not exist. '
                'Run migrations first: python manage.py migrate'
            ))
            return
            
        # Step 2: Get existing columns
        existing_columns = self.get_columns('standards_standardsection')
        self.stdout.write(f'Found columns: {", ".join(existing_columns)}')
        
        # Step 3: Remove the problematic 'order' column if it exists
        if 'order' in existing_columns:
            self.stdout.write('Found problematic "order" column, removing it...')
            try:
                with connection.cursor() as cursor:
                    cursor.execute('ALTER TABLE standards_standardsection DROP COLUMN "order"')
                self.stdout.write(self.style.SUCCESS('Successfully removed "order" column'))
            except Exception as e:
                self.stdout.write(self.style.ERROR(f'Error removing "order" column: {e}'))
        
        # Step 4: Add core columns if they don't exist
        core_columns = {
            'section_number': 'VARCHAR(50)',
            'title': 'VARCHAR(255)',
            'content': 'TEXT'
        }
        
        for column, data_type in core_columns.items():
            if column not in existing_columns:
                self.stdout.write(f'Adding {column} column...')
                try:
                    with connection.cursor() as cursor:
                        cursor.execute(f'ALTER TABLE standards_standardsection ADD COLUMN {column} {data_type}')
                    self.stdout.write(self.style.SUCCESS(f'Added {column} column'))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error adding {column}: {e}'))
        
        self.stdout.write(self.style.SUCCESS('Schema check completed!'))
    
    def table_exists(self, table_name):
        """Check if a table exists in the database"""
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_name = %s
                )
            """, [table_name])
            return cursor.fetchone()[0]
    
    def get_columns(self, table_name):
        """Get a list of column names for a table"""
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = %s
            """, [table_name])
            return [row[0] for row in cursor.fetchall()]
