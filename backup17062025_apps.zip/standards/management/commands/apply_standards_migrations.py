from django.core.management.base import BaseCommand
from django.db import connection, transaction
from django.core.management import call_command

class Command(BaseCommand):
    help = 'Safely apply standards migrations'

    def handle(self, *args, **options):
        self.stdout.write(self.style.WARNING('Starting to safely apply standards migrations...'))
        
        try:
            # First, check what migrations need to be applied
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT name FROM django_migrations 
                    WHERE app = 'standards'
                    ORDER BY id
                """)
                applied_migrations = [row[0] for row in cursor.fetchall()]
            
            self.stdout.write(f"Applied migrations: {', '.join(applied_migrations)}")
            
            # If we already have the fix_completed_manually migration, we're good
            if 'fix_completed_manually' in applied_migrations:
                self.stdout.write(self.style.SUCCESS('Database already fixed manually, skipping migrations'))
                return
            
            # If migration history is empty, fake the initial migration
            if not applied_migrations:
                self.stdout.write('No migrations applied yet, faking initial migration')
                call_command('migrate', 'standards', '0001_initial', fake=True)
            
            # Mark all migrations as completed
            self.stdout.write('Marking all migrations as completed...')
            with connection.cursor() as cursor:
                cursor.execute("""
                    DELETE FROM django_migrations 
                    WHERE app = 'standards'
                """)
                
                # Add fake migration records for all expected migrations
                migrations = [
                    '0001_initial',
                    '0002_standardsection_level_standardsection_lft_and_more',
                    'fix_completed_manually'
                ]
                
                for migration in migrations:
                    cursor.execute("""
                        INSERT INTO django_migrations (app, name, applied)
                        VALUES (%s, %s, NOW())
                    """, ['standards', migration])
            
            self.stdout.write(self.style.SUCCESS('Successfully marked all migrations as applied!'))
            
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error: {str(e)}'))
            return
        
        self.stdout.write(self.style.SUCCESS('Standards app migrations handled successfully!'))
