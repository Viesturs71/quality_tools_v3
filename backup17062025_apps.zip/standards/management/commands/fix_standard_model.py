from django.core.management.base import BaseCommand
from django.db import connection, transaction

class Command(BaseCommand):
    help = 'Fix database schema for Standard model'

    def handle(self, *args, **options):
        self.stdout.write(self.style.WARNING('Starting database fix for Standard model...'))
        
        try:
            with transaction.atomic():
                # Check if the table exists
                with connection.cursor() as cursor:
                    cursor.execute("""
                        SELECT EXISTS (
                            SELECT FROM information_schema.tables 
                            WHERE table_name = 'standards_standard'
                        )
                    """)
                    table_exists = cursor.fetchone()[0]
                
                if not table_exists:
                    self.stdout.write(self.style.ERROR('Table standards_standard does not exist.'))
                    return
                
                # Get existing columns
                with connection.cursor() as cursor:
                    cursor.execute("""
                        SELECT column_name FROM information_schema.columns 
                        WHERE table_name = 'standards_standard'
                    """)
                    existing_columns = [row[0] for row in cursor.fetchall()]
                
                # Required fields for Standard model
                required_columns = {
                    'number': 'VARCHAR(50) NOT NULL',
                    'title': 'VARCHAR(255) NOT NULL',
                    'description': 'TEXT NULL',
                    'issuing_body': 'VARCHAR(100) NULL',
                    'is_active': 'BOOLEAN NOT NULL DEFAULT TRUE',
                    'created_at': 'TIMESTAMP WITH TIME ZONE NULL DEFAULT NOW()',
                    'updated_at': 'TIMESTAMP WITH TIME ZONE NULL DEFAULT NOW()'
                }
                
                # Add missing columns
                with connection.cursor() as cursor:
                    for column, data_type in required_columns.items():
                        if column not in existing_columns:
                            self.stdout.write(f'Adding missing column: {column}')
                            cursor.execute(f"""
                                ALTER TABLE standards_standard 
                                ADD COLUMN {column} {data_type}
                            """)
                
                self.stdout.write(self.style.SUCCESS('Standard model schema fixed.'))
                
                # Make sure there's at least one standard
                with connection.cursor() as cursor:
                    cursor.execute("""
                        SELECT COUNT(*) FROM standards_standard
                    """)
                    count = cursor.fetchone()[0]
                    
                    if count == 0:
                        self.stdout.write('Adding a sample standard...')
                        cursor.execute("""
                            INSERT INTO standards_standard (number, title)
                            VALUES ('STD-001', 'Sample Standard')
                        """)
                
                self.stdout.write(self.style.SUCCESS('Database fix completed successfully!'))
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error: {str(e)}'))
