from accounts.custom_admin import admin_site as custom_admin_site


def get_standard_admin():
    from quality_docs.admin import StandardAdmin

    return StandardAdmin


__all__ = ["custom_admin_site", "StandardAdmin"]
