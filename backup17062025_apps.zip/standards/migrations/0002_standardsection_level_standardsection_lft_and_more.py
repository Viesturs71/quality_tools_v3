from django.db import migrations, models

class Migration(migrations.Migration):
    """Migration to add MPTT fields to StandardSection model"""
    
    dependencies = [
        ('standards', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='standardsection',
            name='level',
            field=models.PositiveIntegerField(default=0, editable=False),
        ),
        migrations.AddField(
            model_name='standardsection',
            name='lft',
            field=models.PositiveIntegerField(default=0, editable=False),
        ),
        migrations.AddField(
            model_name='standardsection',
            name='rght',
            field=models.PositiveIntegerField(default=0, editable=False),
        ),
        migrations.AddField(
            model_name='standardsection',
            name='tree_id',
            field=models.PositiveIntegerField(default=0, editable=False),
        ),
    ]
