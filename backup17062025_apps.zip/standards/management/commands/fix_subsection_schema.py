from django.core.management.base import BaseCommand
from django.db import connection, ProgrammingError

class Command(BaseCommand):
    help = 'Fix StandardSubsection schema or inspect model structure'

    def handle(self, *args, **options):
        self.stdout.write('Analyzing StandardSubsection model...')
        
        # First check if the model is registered
        self.check_model_registration()
        
        # Then check if the table exists
        if self.check_table_exists('standards_standardsubsection'):
            self.fix_existing_table()
        else:
            self.stdout.write(self.style.WARNING('Table standards_standardsubsection does not exist.'))
            self.stdout.write(self.style.WARNING('This might be normal if the model is not yet migrated.'))
            self.stdout.write(self.style.WARNING('You need to run migrations first:'))
            self.stdout.write(self.style.WARNING('  python manage.py makemigrations standards'))
            self.stdout.write(self.style.WARNING('  python manage.py migrate standards'))
        
        self.stdout.write(self.style.SUCCESS('Analysis completed!'))
    
    def check_model_registration(self):
        """Check if the model is properly registered in Django"""
        try:
            from django.apps import apps
            model = apps.get_model('standards', 'StandardSubsection')
            self.stdout.write(f'Model is registered: {model._meta.label}')
            self.stdout.write(f'DB Table: {model._meta.db_table}')
            self.stdout.write(f'Fields: {", ".join(f.name for f in model._meta.fields)}')
        except LookupError:
            self.stdout.write(self.style.ERROR('Model StandardSubsection is not registered!'))
            self.stdout.write(self.style.WARNING('Check if the model is defined in standards/models/standard.py'))
            self.stdout.write(self.style.WARNING('And make sure it\'s imported in the __init__.py file'))
    
    def check_table_exists(self, table_name):
        """Check if a table exists in the database"""
        with connection.cursor() as cursor:
            try:
                cursor.execute(f"""
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables 
                        WHERE table_name = %s
                    )
                """, [table_name])
                exists = cursor.fetchone()[0]
                if exists:
                    self.stdout.write(f'Table {table_name} exists.')
                return exists
            except ProgrammingError:
                self.stdout.write(self.style.ERROR(f'Error checking if {table_name} exists.'))
                return False
    
    def fix_existing_table(self):
        """Fix the schema for an existing table"""
        # Get existing columns
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = 'standards_standardsubsection'
            """)
            existing_columns = [row[0] for row in cursor.fetchall()]
            
            if existing_columns:
                self.stdout.write(f"Found columns: {', '.join(existing_columns)}")
            else:
                self.stdout.write(self.style.WARNING("Table exists but has no columns!"))
        
        # Check if order field exists
        if 'order' not in existing_columns:
            self.stdout.write('Adding order field...')
            with connection.cursor() as cursor:
                try:
                    cursor.execute("""
                        ALTER TABLE standards_standardsubsection 
                        ADD COLUMN "order" INTEGER DEFAULT 0
                    """)
                    self.stdout.write(self.style.SUCCESS('Added order field successfully!'))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error adding order field: {e}'))
        else:
            self.stdout.write(self.style.SUCCESS('Order field already exists!'))
