from django.core.management.base import BaseCommand
import os

class Command(BaseCommand):
    help = 'Update StandardSectionAdmin to use dual title fields'

    def handle(self, *args, **options):
        self.stdout.write('Updating StandardSectionAdmin to use dual title fields...')
        
        # Define path to admin.py
        admin_path = os.path.join('standards', 'admin.py')
        project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        full_path = os.path.join(project_root, admin_path)
        
        if not os.path.exists(full_path):
            self.stdout.write(self.style.ERROR(f'Admin file not found at {full_path}'))
            return
            
        self.stdout.write(f'Found admin file at {full_path}')
        
        # Read the current content
        with open(full_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Define the updated get_form method code
        updated_code = '''
    def get_form(self, request, obj=None, **kwargs):
        """Create a form with two title fields"""
        # Ensure basic columns exist
        self.ensure_basic_columns()
        
        # Check which fields actually exist in the model
        model_fields = [f.name for f in self.model._meta.get_fields()]
        
        # Start with basic fields
        available_fields = ['standard', 'section_number']
        
        # Add title fields if they exist
        has_dual_titles = 'title_original' in model_fields and 'title_user' in model_fields
        if has_dual_titles:
            available_fields.extend(['title_original', 'title_user'])
        elif 'title' in model_fields:
            available_fields.append('title')
        
        # Add content field if it exists
        if 'content' in model_fields:
            available_fields.append('content')
        
        # Set up fieldsets based on available fields
        fieldsets = [
            (_('Standard Information'), {
                'fields': ['standard', 'section_number'],
                'description': _('Select the standard and enter the section number')
            }),
        ]
        
        # Create content section with available fields
        content_fields = []
        
        if has_dual_titles:
            content_fields.extend(['title_original', 'title_user'])
        elif 'title' in model_fields:
            content_fields.append('title')
            
        if 'content' in model_fields:
            content_fields.append('content')
            
        if content_fields:
            fieldsets.append(
                (_('Section Content'), {
                    'fields': content_fields,
                    'description': _('Enter section titles and content')
                })
            )
        
        # Set fields and fieldsets
        kwargs['fields'] = available_fields
        self.fieldsets = fieldsets
        
        form = super().get_form(request, obj, **kwargs)
        
        # Customize form fields for dual titles
        if has_dual_titles:
            from django import forms
            if 'title_original' in form.base_fields:
                form.base_fields['title_original'].widget = forms.Textarea(attrs={
                    'rows': 3,
                    'style': 'width: 100%;',
                    'placeholder': _('Original Section Title')
                })
                form.base_fields['title_original'].label = _('Section Title (original)')
                form.base_fields['title_original'].required = False
            
            if 'title_user' in form.base_fields:
                form.base_fields['title_user'].widget = forms.Textarea(attrs={
                    'rows': 3,
                    'style': 'width: 100%;',
                    'placeholder': _('User-defined Section Title')
                })
                form.base_fields['title_user'].label = _('Section Title (user)')
        elif 'title' in form.base_fields:
            from django import forms
            form.base_fields['title'].widget = forms.Textarea(attrs={
                'rows': 3,
                'style': 'width: 100%;',
                'placeholder': _('Section Title')
            })
        
        if 'content' in form.base_fields:
            form.base_fields['content'].widget.attrs['placeholder'] = _('Section content')
        
        return form'''
        
        # Replace the get_form method in the content
        import re
        pattern = r'def get_form\(self, request, obj=None, \*\*kwargs\):(.*?)def'
        replacement = updated_code + '\n\n    def'
        
        # Use re.DOTALL to match across multiple lines
        new_content = re.sub(pattern, replacement, content, flags=re.DOTALL)
        
        # Write the updated content back to the file
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(new_content)
        
        self.stdout.write(self.style.SUCCESS('Updated StandardSectionAdmin to use dual title fields'))
        self.stdout.write(self.style.WARNING('Restart your Django server to apply the changes'))
