from django.core.management.base import BaseCommand
from django.db import connection

class Command(BaseCommand):
    help = 'Add translation columns to StandardSection table'

    def handle(self, *args, **options):
        self.stdout.write('Adding translation columns to StandardSection...')
        
        # Check if table exists
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_name = 'standards_standardsection'
                )
            """)
            table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            self.stdout.write(self.style.ERROR('Table standards_standardsection does not exist!'))
            self.stdout.write('Run migrations first: python manage.py migrate standards')
            return
            
        # Get existing columns
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = 'standards_standardsection'
            """)
            existing_columns = [row[0] for row in cursor.fetchall()]
            
        self.stdout.write(f'Found columns: {", ".join(existing_columns)}')
        
        # Add translation columns
        translation_columns = {
            'title_en': 'VARCHAR(255) NULL',
            'content_en': 'TEXT NULL',
        }
        
        for column, data_type in translation_columns.items():
            if column not in existing_columns:
                self.stdout.write(f'Adding {column} column...')
                try:
                    with connection.cursor() as cursor:
                        cursor.execute(f"""
                            ALTER TABLE standards_standardsection 
                            ADD COLUMN {column} {data_type}
                        """)
                    self.stdout.write(self.style.SUCCESS(f'Added {column} column'))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error adding {column}: {e}'))
            else:
                self.stdout.write(f'{column} already exists')
        
        self.stdout.write(self.style.SUCCESS('Translation columns setup complete!'))
