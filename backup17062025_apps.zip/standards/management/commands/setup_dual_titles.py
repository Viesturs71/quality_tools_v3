
from django.core.management.base import BaseCommand
from django.db import connection

class Command(BaseCommand):
    help = 'Set up the database schema for dual titles in StandardSection'

    def handle(self, *args, **options):
        self.stdout.write('Setting up dual title fields for StandardSection...')
        
        # Check if table exists
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_name = 'standards_standardsection'
                )
            """)
            table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            self.stdout.write(self.style.ERROR('Table standards_standardsection does not exist!'))
            self.stdout.write('Run migrations first: python manage.py migrate standards')
            return
            
        # Get existing columns
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = 'standards_standardsection'
            """)
            existing_columns = [row[0] for row in cursor.fetchall()]
            
        self.stdout.write(f'Found columns: {", ".join(existing_columns)}')
        
        # Remove problematic 'order' column if it exists
        if 'order' in existing_columns:
            self.stdout.write('Found problematic "order" column, attempting to remove...')
            try:
                with connection.cursor() as cursor:
                    cursor.execute('ALTER TABLE standards_standardsection DROP COLUMN "order"')
                self.stdout.write(self.style.SUCCESS('Removed "order" column'))
            except Exception as e:
                self.stdout.write(self.style.ERROR(f'Error removing "order" column: {e}'))
                try:
                    with connection.cursor() as cursor:
                        cursor.execute('ALTER TABLE standards_standardsection RENAME COLUMN "order" TO sort_order')
                    self.stdout.write(self.style.SUCCESS('Renamed "order" to "sort_order"'))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error renaming column: {e}'))
        
        # Add required columns
        required_columns = {
            'section_number': 'VARCHAR(50) NULL',
            'title': 'TEXT NULL',
            'content': 'TEXT NULL',
        }
        
        # First make sure basic columns exist
        for column, data_type in required_columns.items():
            if column not in existing_columns:
                self.stdout.write(f'Adding {column} column...')
                try:
                    with connection.cursor() as cursor:
                        cursor.execute(f"""
                            ALTER TABLE standards_standardsection 
                            ADD COLUMN {column} {data_type}
                        """)
                    self.stdout.write(self.style.SUCCESS(f'Added {column} column'))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error adding {column}: {e}'))
        
        # Now add dual title column for the future
        if 'title_original' not in existing_columns:
            self.stdout.write('Adding title_original column for dual title support...')
            try:
                with connection.cursor() as cursor:
                    cursor.execute("""
                        ALTER TABLE standards_standardsection 
                        ADD COLUMN title_original TEXT NULL
                    """)
                self.stdout.write(self.style.SUCCESS('Added title_original column'))
                
                # Copy existing title values to title_original to preserve data
                cursor.execute("""
                    UPDATE standards_standardsection
                    SET title_original = title
                    WHERE title IS NOT NULL
                """)
                self.stdout.write(self.style.SUCCESS('Copied existing title values to title_original'))
            except Exception as e:
                self.stdout.write(self.style.ERROR(f'Error setting up title_original: {e}'))
        
        self.stdout.write(self.style.SUCCESS('StandardSection schema setup complete!'))
        self.stdout.write(self.style.WARNING('Run this command again if you want to enable dual title support.'))
