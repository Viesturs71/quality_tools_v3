from django.core.management.base import BaseCommand
from django.db import connection

class Command(BaseCommand):
    help = 'Add dual title fields (original and user) to StandardSection'

    def handle(self, *args, **options):
        self.stdout.write('Adding dual title fields to StandardSection...')
        
        # Check if table exists
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_name = 'standards_standardsection'
                )
            """)
            table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            self.stdout.write(self.style.ERROR('Table standards_standardsection does not exist!'))
            self.stdout.write('Run migrations first: python manage.py migrate standards')
            return
            
        # Get existing columns
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = 'standards_standardsection'
            """)
            existing_columns = [row[0] for row in cursor.fetchall()]
            
        self.stdout.write(f'Found columns: {", ".join(existing_columns)}')
        
        # 1. First handle the 'order' column if it exists
        if 'order' in existing_columns:
            self.stdout.write('Found problematic "order" column, attempting to remove...')
            try:
                with connection.cursor() as cursor:
                    cursor.execute('ALTER TABLE standards_standardsection DROP COLUMN "order"')
                self.stdout.write(self.style.SUCCESS('Removed "order" column'))
            except Exception as e:
                self.stdout.write(self.style.ERROR(f'Error removing "order" column: {e}'))
        
        # 2. Add both title fields if they don't exist
        title_fields = {
            'title_original': 'TEXT NULL',  # First title field
            'title_user': 'TEXT NULL',     # Second title field
        }
        
        for column, data_type in title_fields.items():
            if column not in existing_columns:
                self.stdout.write(f'Adding {column} column...')
                try:
                    with connection.cursor() as cursor:
                        cursor.execute(f"""
                            ALTER TABLE standards_standardsection 
                            ADD COLUMN {column} {data_type}
                        """)
                    self.stdout.write(self.style.SUCCESS(f'Added {column} column'))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error adding {column} column: {e}'))
        
        # 3. If title exists but new title fields don't have data, copy data to maintain existing values
        if 'title' in existing_columns and 'title_original' in existing_columns:
            self.stdout.write('Copying existing title values to new title fields where needed...')
            try:
                with connection.cursor() as cursor:
                    # Copy to title_original
                    cursor.execute("""
                        UPDATE standards_standardsection
                        SET title_original = title
                        WHERE title_original IS NULL AND title IS NOT NULL
                    """)
                    
                    # Also copy to title_user if it exists
                    if 'title_user' in existing_columns:
                        cursor.execute("""
                            UPDATE standards_standardsection
                            SET title_user = title
                            WHERE title_user IS NULL AND title IS NOT NULL
                        """)
                self.stdout.write(self.style.SUCCESS('Copied existing title values to new fields'))
            except Exception as e:
                self.stdout.write(self.style.ERROR(f'Error copying title values: {e}'))
        
        # 4. Ensure all other required columns exist
        required_columns = {
            'section_number': 'VARCHAR(50) NULL',
            'title': 'TEXT NULL',
            'content': 'TEXT NULL',
        }
        
        for column, data_type in required_columns.items():
            if column not in existing_columns:
                self.stdout.write(f'Adding {column} column...')
                try:
                    with connection.cursor() as cursor:
                        cursor.execute(f"""
                            ALTER TABLE standards_standardsection 
                            ADD COLUMN {column} {data_type}
                        """)
                    self.stdout.write(self.style.SUCCESS(f'Added {column} column'))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error adding {column}: {e}'))
        
        self.stdout.write(self.style.SUCCESS('Dual title setup complete!'))
