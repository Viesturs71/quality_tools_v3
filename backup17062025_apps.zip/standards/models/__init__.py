"""
Standards models initialization.
All standard-related models are defined in standard.py (singular).
"""

# Import models from the standard.py file
from .standard import (
    Standard, StandardSection, StandardSubsection, StandardDocument,
    StandardRequirement, StandardAttachment, StandardRevision,
    StandardComplianceStatus
)

# Export all models
__all__ = [
    'Standard', 'StandardSection', 'StandardSubsection', 'StandardDocument',
    'StandardRequirement', 'StandardAttachment', 'StandardRevision',
    'StandardComplianceStatus'
]
