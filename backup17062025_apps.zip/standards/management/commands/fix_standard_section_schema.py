from django.core.management.base import BaseCommand
from django.db import connection

class Command(BaseCommand):
    help = 'Fix the database schema for StandardSection to support bilingual content'

    def handle(self, *args, **options):
        self.stdout.write('Starting to fix StandardSection schema...')
        
        # Get existing columns
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = 'standards_standardsection'
            """)
            existing_columns = [row[0] for row in cursor.fetchall()]
            
            self.stdout.write(f"Existing columns: {', '.join(existing_columns)}")
        
        # Define columns to add
        columns_to_add = {
            'section_number': 'VARCHAR(50)',
            'title': 'VARCHAR(255)',
            'title_en': 'VARCHAR(255)',
            'content': 'TEXT',
            'content_en': 'TEXT',
            'parent_id': 'INTEGER',
            'sort_order': 'INTEGER'  # Changed from 'order' to 'sort_order' to avoid SQL keyword
        }
        
        # Add missing columns
        added_columns = []
        with connection.cursor() as cursor:
            for column, data_type in columns_to_add.items():
                if column not in existing_columns:
                    self.stdout.write(f'Adding column {column}...')
                    try:
                        sql = f"ALTER TABLE standards_standardsection ADD COLUMN {column} {data_type}"
                        if column == 'sort_order':
                            sql += " DEFAULT 0"
                        cursor.execute(sql)
                        added_columns.append(column)
                    except Exception as e:
                        self.stdout.write(self.style.ERROR(f"Error adding column {column}: {e}"))
        
        if added_columns:
            self.stdout.write(self.style.SUCCESS(f"Added columns: {', '.join(added_columns)}"))
        else:
            self.stdout.write(self.style.SUCCESS("All required columns already exist."))
        
        self.stdout.write(self.style.SUCCESS('StandardSection schema fixed!'))
