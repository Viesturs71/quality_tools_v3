# accounts/forms.py
from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

User = get_user_model()  # ✅ Nodrošina pareizu lietotāja modeli


class RegisterForm(UserCreationForm):
    email = forms.EmailField(help_text="Ievadiet derīgu e-pasta adresi.")

    class Meta:
        model = User
        fields = ["username", "email", "password1", "password2"]

    def clean_email(self):
        email = self.cleaned_data.get("email")
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError("Šī e-pasta adrese jau ir reģistrēta.")
        return email


class CustomUserCreationForm(forms.ModelForm):
    class Meta:
        model = User
        fields = (
            "username",
            "email",
            "first_name",
            "last_name",
            "is_staff",
            "is_active",
        )
