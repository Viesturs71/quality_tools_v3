from django.core.management.base import BaseCommand
from django.db import connection
import os
import shutil

class Command(BaseCommand):
    help = 'Reset migrations for the standards app to fix MPTT issues'

    def handle(self, *args, **options):
        self.stdout.write(self.style.WARNING('Starting migration reset for standards app...'))
        
        # Get migrations directory path
        project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        migrations_dir = os.path.join(project_root, 'standards', 'migrations')
        
        try:
            # 1. Backup the existing migrations
            backup_dir = os.path.join(migrations_dir, 'backup')
            os.makedirs(backup_dir, exist_ok=True)
            
            # Copy all migration files to backup directory
            for filename in os.listdir(migrations_dir):
                if filename.endswith('.py') and filename != '__init__.py':
                    shutil.copy(
                        os.path.join(migrations_dir, filename),
                        os.path.join(backup_dir, filename)
                    )
                    self.stdout.write(f'Backed up {filename}')
            
            # 2. Remove the problematic migrations
            for filename in os.listdir(migrations_dir):
                if filename.endswith('.py') and filename != '__init__.py':
                    os.remove(os.path.join(migrations_dir, filename))
                    self.stdout.write(f'Removed {filename}')
            
            # 3. Reset the migration history in the database
            with connection.cursor() as cursor:
                cursor.execute("""
                    DELETE FROM django_migrations 
                    WHERE app = 'standards'
                """)
                self.stdout.write(self.style.SUCCESS('Cleared migration history for standards app'))
            
            # 4. Fix the database tables by dropping MPTT fields
            try:
                with connection.cursor() as cursor:
                    # First check if the table exists
                    cursor.execute("""
                        SELECT EXISTS (
                            SELECT FROM information_schema.tables 
                            WHERE table_name = 'standards_standardsection'
                        )
                    """)
                    table_exists = cursor.fetchone()[0]
                    
                    if table_exists:
                        # Check if the problematic MPTT fields exist
                        cursor.execute("""
                            SELECT column_name FROM information_schema.columns 
                            WHERE table_name = 'standards_standardsection'
                        """)
                        columns = [row[0] for row in cursor.fetchall()]
                        
                        # Drop the problematic MPTT fields
                        mptt_fields = ['level', 'lft', 'rght', 'tree_id']
                        for field in mptt_fields:
                            if field in columns:
                                cursor.execute(f"""
                                    ALTER TABLE standards_standardsection 
                                    DROP COLUMN IF EXISTS {field}
                                """)
                                self.stdout.write(f'Dropped {field} field')
                
                self.stdout.write(self.style.SUCCESS('Fixed database structure'))
            
            except Exception as e:
                self.stdout.write(self.style.ERROR(f'Error fixing database structure: {str(e)}'))
            
            # 5. Create a new initial migration
            self.stdout.write(self.style.WARNING('Now run these commands:'))
            self.stdout.write('1. python manage.py makemigrations standards')
            self.stdout.write('2. python manage.py migrate standards')
            
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error: {str(e)}'))
