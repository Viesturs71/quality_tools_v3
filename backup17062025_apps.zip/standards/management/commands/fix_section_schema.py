from django.core.management.base import BaseCommand
from django.db import connection

class Command(BaseCommand):
    help = 'Fix database schema for StandardSection'

    def handle(self, *args, **options):
        self.stdout.write('Fixing database schema for StandardSection...')
        
        # Check if table exists
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_name = 'standards_standardsection'
                )
            """)
            table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            self.stdout.write(self.style.ERROR('Table standards_standardsection does not exist!'))
            return
            
        # Get existing columns
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = 'standards_standardsection'
            """)
            existing_columns = [row[0] for row in cursor.fetchall()]
            
        self.stdout.write(f'Found columns: {", ".join(existing_columns)}')
        
        # Required columns for StandardSection
        required_columns = {
            'id': 'SERIAL PRIMARY KEY',
            'section_number': 'VARCHAR(50) NULL',
            'title': 'TEXT NULL',
            'title_user': 'TEXT NULL',
            'content': 'TEXT NULL',
            'display_order': 'INTEGER NULL DEFAULT 0',
            'created_at': 'TIMESTAMP WITH TIME ZONE NULL DEFAULT NOW()',
            'updated_at': 'TIMESTAMP WITH TIME ZONE NULL DEFAULT NOW()',
            'parent_id': 'INTEGER NULL REFERENCES standards_standardsection(id) ON DELETE CASCADE',
            'standard_id': 'INTEGER NOT NULL REFERENCES standards_standard(id) ON DELETE CASCADE',
        }
        
        # Add missing columns
        added_columns = []
        for column, data_type in required_columns.items():
            if column not in existing_columns and column != 'id':  # Skip id, it should be created with the table
                self.stdout.write(f'Adding missing column: {column}')
                try:
                    with connection.cursor() as cursor:
                        cursor.execute(f"""
                            ALTER TABLE standards_standardsection 
                            ADD COLUMN {column} {data_type}
                        """)
                    added_columns.append(column)
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error adding column {column}: {str(e)}'))
        
        if added_columns:
            self.stdout.write(self.style.SUCCESS(f'Added {len(added_columns)} columns: {", ".join(added_columns)}'))
        else:
            self.stdout.write(self.style.SUCCESS('All required columns already exist.'))
            
        self.stdout.write(self.style.SUCCESS('Schema fix completed! Run migrations next.'))
