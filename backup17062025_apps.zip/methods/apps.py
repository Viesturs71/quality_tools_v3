# methods/apps.py
from django.apps import AppConfig


class MethodsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'methods'
    verbose_name = 'Metodes'
