"""Admin configuration for the company app."""

from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from .models import Company, Department, Location
from accounts.admin import custom_admin_site

# Create a minimal admin for Company that only uses fields that exist in the database
@admin.register(Company, site=custom_admin_site)
class CompanyAdmin(admin.ModelAdmin):
    list_display = ('name', 'is_active', 'email', 'phone')
    list_filter = ('is_active',)
    search_fields = ('name', 'registration_number', 'email')
    fieldsets = (
        (None, {
            'fields': ('name', 'registration_number', 'identifier')
        }),
        ('Contact Information', {
            'fields': ('address', 'city', 'state_province', 'country', 'postal_code', 'email', 'phone', 'website')
        }),
        ('Status', {
            'fields': ('is_active',)
        }),
    )

@admin.register(Department, site=custom_admin_site)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ('name', 'company', 'is_active')
    search_fields = ('name', 'description')
    list_filter = ('is_active', 'company')
    fieldsets = (
        (None, {
            'fields': ('name', 'code', 'company', 'description', 'is_active')
        }),
    )

@admin.register(Location, site=custom_admin_site)
class LocationAdmin(admin.ModelAdmin):
    list_display = ('name', 'company', 'is_active')
    search_fields = ('name', 'address')
    list_filter = ('is_active', 'company')
    fieldsets = (
        (None, {
            'fields': ('name', 'address', 'city', 'postal_code', 'country', 'company', 'is_active')
        }),
    )
        )
    
    fieldsets = (
        (None, {
            'fields': ('name', 'company', 'description')
        }),
    )

@admin.register(Location, site=custom_admin_site)
class LocationAdmin(admin.ModelAdmin):
    list_display = ('name', 'company_name')
    search_fields = ('name',)
    
    def company_name(self, obj):
        """Return company name to avoid direct company reference in list display"""
        return obj.company.name if obj.company else '-'
    company_name.short_description = 'Company'
    
    def get_queryset(self, request):
        """Optimize queryset to prefetch company data and avoid missing fields"""
        qs = super().get_queryset(request)
        # Ensure we only select fields that actually exist in the database
        return qs.select_related('company').only(
            'id', 'name', 'address', 'company__id', 'company__name'
        )
    
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        """Customize company dropdown to only show id and name"""
        if db_field.name == "company":
            kwargs["queryset"] = Company.objects.only('id', 'name')
        return super().formfield_for_foreignkey(db_field, request, **kwargs)
    
    # Only include fields that definitely exist in the database
    fieldsets = (
        (None, {
            'fields': ('name', 'address', 'company')
        }),
    )
