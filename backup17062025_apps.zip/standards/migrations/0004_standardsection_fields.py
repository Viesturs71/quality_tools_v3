from django.db import migrations, models

class Migration(migrations.Migration):
    """Migration to add additional fields to StandardSection model"""
    
    dependencies = [
        ('standards', '0003_fix_mptt_fields'),
    ]

    operations = [
        # Add title_user and content fields
        migrations.AddField(
            model_name='standardsection',
            name='title_user',
            field=models.TextField(blank=True, null=True, verbose_name='Section Title (User Language)'),
        ),
        migrations.AddField(
            model_name='standardsection',
            name='content',
            field=models.TextField(blank=True, null=True, verbose_name='Content'),
        ),
        migrations.AddField(
            model_name='standardsection',
            name='display_order',
            field=models.PositiveIntegerField(default=0, verbose_name='Display Order'),
        ),
    ]
