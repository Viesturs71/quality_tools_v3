from django.apps import AppConfig

class StandardsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'standards'  # Ensure this matches the app directory name
