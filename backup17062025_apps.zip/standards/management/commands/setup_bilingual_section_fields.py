from django.core.management.base import BaseCommand
from django.db import connection

class Command(BaseCommand):
    help = 'Set up bilingual section fields for side-by-side editing'

    def handle(self, *args, **options):
        self.stdout.write('Setting up bilingual section fields for side-by-side editing...')
        
        # Check if table exists
        if not self.table_exists('standards_standardsection'):
            self.stdout.write(self.style.ERROR('Standards section table does not exist.'))
            self.stdout.write(self.style.WARNING('Run migrations first: python manage.py migrate'))
            return
            
        # Get existing columns
        existing_columns = self.get_columns('standards_standardsection')
        self.stdout.write(f'Found columns: {", ".join(existing_columns)}')
        
        # Add or modify columns to make titles and content consistent
        required_columns = {
            'section_number': 'VARCHAR(50)',
            'title': 'TEXT',          # Local language title
            'content': 'TEXT',        # Local language content
            'title_en': 'TEXT',       # English title
            'content_en': 'TEXT'      # English content
        }
        
        # Process each column
        for column, data_type in required_columns.items():
            if column not in existing_columns:
                # Add missing column
                self.stdout.write(f'Adding column {column}...')
                try:
                    with connection.cursor() as cursor:
                        cursor.execute(f"""
                            ALTER TABLE standards_standardsection 
                            ADD COLUMN {column} {data_type} NULL
                        """)
                    self.stdout.write(self.style.SUCCESS(f'Added column {column}'))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error adding column {column}: {e}'))
            elif column.startswith('title') and 'VARCHAR' in self.get_column_type(column):
                # Convert title columns from VARCHAR to TEXT
                self.stdout.write(f'Converting {column} to TEXT type...')
                try:
                    with connection.cursor() as cursor:
                        cursor.execute(f"""
                            ALTER TABLE standards_standardsection 
                            ALTER COLUMN {column} TYPE TEXT
                        """)
                    self.stdout.write(self.style.SUCCESS(f'Converted {column} to TEXT type'))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error converting column {column}: {e}'))
        
        self.stdout.write(self.style.SUCCESS('Bilingual side-by-side editing setup complete!'))
    
    def table_exists(self, table_name):
        """Check if a table exists in the database"""
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_name = %s
                )
            """, [table_name])
            return cursor.fetchone()[0]
    
    def get_columns(self, table_name):
        """Get a list of column names for a table"""
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = %s
            """, [table_name])
            return [row[0] for row in cursor.fetchall()]
    
    def get_column_type(self, column_name, table_name='standards_standardsection'):
        """Get the data type of a specific column"""
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT data_type 
                FROM information_schema.columns 
                WHERE table_name = %s AND column_name = %s
            """, [table_name, column_name])
            result = cursor.fetchone()
            return result[0] if result else None
