"""
Equipment module initialization.
"""
default_app_config = 'equipment.apps.EquipmentConfig'
