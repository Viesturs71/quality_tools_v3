## 🌐 **`myprojects/urls.py`**
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.conf.urls.i18n import i18n_patterns
from django.views.generic import RedirectView, TemplateView

urlpatterns = i18n_patterns(
    # Admin URLs
    path('admin/', admin.site.urls),
    
    # Add Rosetta URLs directly in i18n_patterns
    path('rosetta/', include('rosetta.urls')),
    
    # Language switching URLs
    path('i18n/', include('django.conf.urls.i18n')),
    
    # App URLs with proper namespaces
    path('dashboard/', include('dashboard.urls', namespace='dashboard')),
    path('equipment/', include('equipment.urls', namespace='equipment')),
    path('personnel/', include('personnel.urls', namespace='personnel')),
    path('quality-docs/', include('quality_docs.urls', namespace='quality_docs')),
    path('standards/', include('standards.urls', namespace='standards')),
    path('accounts/', include('accounts.urls', namespace='accounts')),
    
    # Home redirect
    path('', RedirectView.as_view(url='/dashboard/', permanent=False), name='home'),
    
    # Static pages
    path('about/', TemplateView.as_view(template_name='pages/about.html'), name='about'),
    
    prefix_default_language=False,
)

# Serve media files in development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
