from django.core.management.base import BaseCommand
from django.db import connection, transaction

class Command(BaseCommand):
    help = 'Fix StandardSection ordering issues'

    def handle(self, *args, **options):
        self.stdout.write(self.style.WARNING('Starting fix for StandardSection ordering...'))
        
        try:
            with transaction.atomic():
                # Check if the table exists
                with connection.cursor() as cursor:
                    cursor.execute("""
                        SELECT EXISTS (
                            SELECT FROM information_schema.tables 
                            WHERE table_name = 'standards_standardsection'
                        )
                    """)
                    table_exists = cursor.fetchone()[0]
                
                if not table_exists:
                    self.stdout.write(self.style.ERROR('Table standards_standardsection does not exist.'))
                    return
                
                # Get all sections without display_order
                with connection.cursor() as cursor:
                    cursor.execute("""
                        SELECT id, section_number 
                        FROM standards_standardsection 
                        WHERE display_order IS NULL OR display_order = 0
                    """)
                    sections = cursor.fetchall()
                
                # Update display_order based on section_number
                for i, (section_id, section_number) in enumerate(sections):
                    # Try to get a numeric value from section_number
                    try:
                        # Extract the first number from the section number
                        import re
                        match = re.search(r'(\d+)', section_number)
                        if match:
                            order_value = int(match.group(1)) * 10
                        else:
                            # If no number found, use the sequence
                            order_value = (i + 1) * 10
                    except:
                        # If all else fails, just use the sequence
                        order_value = (i + 1) * 10
                    
                    # Update the display_order
                    with connection.cursor() as cursor:
                        cursor.execute("""
                            UPDATE standards_standardsection 
                            SET display_order = %s 
                            WHERE id = %s
                        """, [order_value, section_id])
                
                self.stdout.write(self.style.SUCCESS(f'Updated display_order for {len(sections)} sections'))
                
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error: {str(e)}'))
