from django.views.generic import TemplateView
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.decorators import login_required
from .models.standard import Standard, StandardSection

class StandardsManagementView(LoginRequiredMixin, TemplateView):
    """
    View for the standards management dashboard.
    """
    template_name = 'standards/management.html'  # Ensure this template exists


class StandardsRegistryView(LoginRequiredMixin, TemplateView):
    """
    View for browsing the standards registry.
    """
    template_name = 'standards/registry.html'


class StandardFormView(LoginRequiredMixin, TemplateView):
    """
    View for the standard creation/edit form.
    """
    template_name = 'standards/standard_form.html'


# Function-based view with login required
@login_required
def management(request):
    """
    Alternative function-based view for the standards management page.
    Consider consolidating this with StandardsManagementView.
    """
    return render(request, 'standards/management.html')


@login_required
def sections_hierarchy(request, standard_id):
    """Display sections hierarchy for a standard"""
    standard = get_object_or_404(Standard, id=standard_id)
    
    # Get top-level sections (those without a parent)
    sections = StandardSection.objects.filter(
        standard=standard,
        parent__isnull=True
    ).order_by('display_order', 'section_number')
    
    return render(request, 'standards/sections_hierarchy.html', {
        'standard': standard,
        'sections': sections,
    })
