# methods/urls.py
from django.urls import path
from . import views  # Import views

app_name = 'methods'  # Pievienojam namespace

urlpatterns = [
    path('', views.MethodListView.as_view(), name='method_list'),
    path('create/', views.MethodCreateView.as_view(), name='method_create'),
    path('<int:pk>/', views.MethodDetailView.as_view(), name='method_detail'),
    path('<int:pk>/update/', views.MethodUpdateView.as_view(), name='method_update'),
]
