from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from mptt.admin import MPTTModelAdmin
from .models.standard import (
    Standard, 
    StandardSection, 
    StandardSubsection, 
    StandardDocument,
    StandardRequirement, 
    StandardAttachment, 
    StandardRevision,
    StandardComplianceStatus
)
from accounts.admin import custom_admin_site

@admin.register(Standard, site=custom_admin_site)
class StandardAdmin(admin.ModelAdmin):
    """Admin for Standard model with minimal fields to avoid DB errors."""
    list_display = ('number', 'title')
    search_fields = ('number', 'title')
    
    # Define only fields that definitely exist
    fields = ('number', 'title', 'description')
    
    def get_fields(self, request, obj=None):
        """Dynamically determine which fields exist in the database"""
        try:
            from django.db import connection
            
            # Get existing columns for standards_standard table
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT column_name FROM information_schema.columns 
                    WHERE table_name = 'standards_standard'
                """)
                existing_columns = [row[0] for row in cursor.fetchall()]
            
            # Start with required fields
            fields = ['number', 'title']
            
            # Add optional fields if they exist
            optional_fields = ['description', 'issuing_body', 'is_active']
            for field in optional_fields:
                if field in existing_columns:
                    fields.append(field)
                    
            return fields
        except:
            # Fallback to basic fields
            return ('number', 'title')
    
    def get_queryset(self, request):
        """Override queryset to select only fields known to exist"""
        qs = super().get_queryset(request)
        
        # Build list of fields to select based on what exists
        try:
            from django.db import connection
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT column_name FROM information_schema.columns 
                    WHERE table_name = 'standards_standard'
                """)
                existing_columns = [row[0] for row in cursor.fetchall()]
            
            # Always include id and essential fields
            select_fields = ['id', 'number', 'title']
            
            # Add optional fields if they exist
            optional_fields = ['description', 'issuing_body', 'is_active', 
                              'created_at', 'updated_at']
            for field in optional_fields:
                if field in existing_columns:
                    select_fields.append(field)
                    
            # Apply only()
            return qs.only(*select_fields)
        except:
            # If any error, return basic queryset
            return qs
    
    def save_model(self, request, obj, form, change):
        """Override save_model to handle all required fields with default values"""
        if change and obj.pk:
            # For updates, only update the specific fields
            original = self.model.objects.get(pk=obj.pk)
            for field in form.cleaned_data:
                setattr(original, field, form.cleaned_data[field])
            original.save()
        else:
            # For new objects, use the simplified approach
            obj.save()

# StandardSection admin with dual section title support
@admin.register(StandardSection, site=custom_admin_site)
class StandardSectionAdmin(admin.ModelAdmin):
    """Admin for StandardSection with original and user-defined titles."""
    list_display = ('get_standard_name', 'section_number', 'get_title_display', 'has_translation')
    # Simpler list_filter without using a relation that might have problematic fields
    list_filter = []  # Remove the standard filter to avoid DB issues
    search_fields = ('section_number', 'title', 'title_user')
    ordering = ('section_number',)  # Simplified ordering
    
    class Media:
        css = {
            'all': ('admin/css/dual_titles.css',)
        }
        
        # Add a JS file to show migration helper message
        js = ('admin/js/migration_helper.js',)
    
    def get_standard_name(self, obj):
        """Display the standard number for this section"""
        try:
            if obj.standard:
                return obj.standard.number
        except:
            pass
        return "-"
    get_standard_name.short_description = _('Standard')
    
    def get_title_display(self, obj):
        """Display the title, with indication if it has both titles"""
        try:
            return obj.title if obj.title else "-"
        except:
            return "-"
    get_title_display.short_description = _('Title')
    
    def has_translation(self, obj):
        """Display whether the section has a user-defined title"""
        try:
            if hasattr(obj, 'title_user') and obj.title_user:
                return "✓"
        except:
            pass
        return "-"
    has_translation.short_description = _('Has Translation')
    
    def get_queryset(self, request):
        """Only select standard and essential fields"""
        qs = super().get_queryset(request)
        
        # Simple version with no complex relations to avoid errors
        return qs.select_related('standard')
    
    def get_deleted_objects(self, objs, request):
        """Override to prevent checking for related objects that don't exist in DB"""
        try:
            # Use the parent implementation but catch any database errors
            return super().get_deleted_objects(objs, request)
        except Exception as e:
            import logging
            logging.getLogger('django').error(f"Error in get_deleted_objects: {e}")
            
            # Provide a simplified version with just the objects being deleted
            from django.contrib.admin.utils import model_ngettext, NestedObjects
            from django.db import router
            
            # Simplified collector that doesn't check for relations
            collector = NestedObjects(using=router.db_for_write(self.model))
            
            # Only collect the objects themselves without related objects
            deletable_objects = [f"{obj}" for obj in objs]
            model_count = {self.model._meta.verbose_name_plural: len(objs)}
            perms_needed = set()
            protected = []
            
            return deletable_objects, model_count, perms_needed, protected
    
    def delete_model(self, request, obj):
        """Override to safely delete without cascading through relations that might not exist"""
        from django.db import connection, transaction, IntegrityError
        from django.contrib.admin.models import LogEntry, DELETION
        from django.contrib.contenttypes.models import ContentType
        from django.utils.encoding import force_str
        
        # Store object info for logging before deletion
        object_id = obj.pk
        content_type = None
        try:
            content_type = ContentType.objects.get_for_model(obj.__class__)
            obj_display = force_str(obj)
        except Exception:
            obj_display = f"StandardSection: {obj.pk}"
        
        # Use transaction.atomic() to ensure the whole process is in a single transaction
        try:
            with transaction.atomic():
                # First try to delete through normal ORM
                try:
                    obj.delete()
                    deleted = True
                except Exception:
                    deleted = False
                
                # If ORM deletion fails, try direct SQL deletion
                if not deleted:
                    with connection.cursor() as cursor:
                        cursor.execute(
                            "DELETE FROM standards_standardsection WHERE id = %s",
                            [object_id]
                        )
                
                # Try to log the deletion (if content type was found)
                if content_type:
                    try:
                        LogEntry.objects.log_action(
                            user_id=request.user.pk,
                            content_type_id=content_type.pk,
                            object_id=object_id,
                            object_repr=obj_display,
                            action_flag=DELETION,
                        )
                    except Exception:
                        # Ignore logging errors
                        pass
                
                # Show success message
                self.message_user(
                    request, 
                    _("The section was successfully deleted."),
                    level='success'
                )
                
        except Exception as e:
            # Show error message
            self.message_user(
                request, 
                _("Error deleting section: %(error)s") % {'error': str(e)},
                level='error'
            )
    
    def delete_queryset(self, request, queryset):
        """Override to safely delete multiple objects"""
        from django.db import connection, transaction
        
        try:
            with transaction.atomic():
                # Store IDs before deletion
                ids = list(queryset.values_list('id', flat=True))
                
                # Try direct database deletion
                with connection.cursor() as cursor:
                    placeholders = ', '.join(['%s'] * len(ids))
                    cursor.execute(
                        f"DELETE FROM standards_standardsection WHERE id IN ({placeholders})",
                        ids
                    )
                
                # No need to log deletions for batch operations
                
                self.message_user(
                    request, 
                    _("The selected sections were successfully deleted."),
                    level='success'
                )
                
        except Exception as e:
            # If batch deletion fails, try one by one
            success_count = 0
            for obj in queryset:
                try:
                    # Use the single-object deletion method which handles transactions
                    self.delete_model(request, obj)
                    success_count += 1
                except Exception:
                    pass
                    
            if success_count > 0:
                self.message_user(
                    request, 
                    _("%(count)d out of %(total)d sections were deleted.") % {
                        'count': success_count,
                        'total': queryset.count()
                    },
                    level='warning'
                )
            else:
                self.message_user(
                    request, 
                    _("Failed to delete any sections."),
                    level='error'
                )

    # ...existing code...
    
    def get_queryset(self, request):
        """Only select standard and essential fields"""
        qs = super().get_queryset(request)
        
        # The error occurs because select_related('standard') tries to fetch the 'revision' column
        # We need to limit what fields are fetched from the Standard model
        
        # First, get a list of columns that actually exist in the standards_standard table
        try:
            from django.db import connection
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT column_name FROM information_schema.columns 
                    WHERE table_name = 'standards_standard'
                """)
                standard_columns = [row[0] for row in cursor.fetchall()]
            
            # If basic columns exist, use select_related with only
            if 'id' in standard_columns and 'number' in standard_columns and 'title' in standard_columns:
                # Start with a basic queryset
                base_qs = qs
                
                # Prefetch the standard relationship with only the fields that exist
                from django.db.models import Prefetch
                from .models.standard import Standard
                
                standards_qs = Standard.objects.only('id', 'number', 'title')
                if 'description' in standard_columns:
                    standards_qs = standards_qs.defer('description')
                
                # Use prefetch_related instead of select_related to have more control
                return base_qs.prefetch_related(
                    Prefetch('standard', queryset=standards_qs),
                    Prefetch('parent')
                )
            else:
                # If standard table doesn't have expected columns, don't use select_related
                return qs
        except Exception as e:
            # Log the error but continue with a basic queryset
            import logging
            logging.getLogger('django').error(f"Error in get_queryset: {e}")
            return qs
    
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        """Pielāgot vecāksadaļas izvēli atkarībā no konteksta"""
        if db_field.name == "standard":
            kwargs["queryset"] = Standard.objects.only('id', 'number', 'title')
        elif db_field.name == "parent":
            kwargs["queryset"] = StandardSection.objects.all()
        return super().formfield_for_foreignkey(db_field, request, **kwargs)

    
    def ensure_basic_columns(self):
        """Add basic columns to the database if they don't exist"""
        try:
            from django.db import connection
            
            # Check if table exists
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables 
                        WHERE table_name = 'standards_standardsection'
                    )
                """)
                table_exists = cursor.fetchone()[0]
                
            if not table_exists:
                # Can't add columns if table doesn't exist
                return
                
            # Get existing columns
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT column_name FROM information_schema.columns 
                    WHERE table_name = 'standards_standardsection'
                """)
                existing_columns = [row[0] for row in cursor.fetchall()]
            
            # Fix MPTT fields if they exist but have wrong data types
            mptt_fields = {
                'level': 'INTEGER',
                'lft': 'INTEGER',
                'rght': 'INTEGER',
                'tree_id': 'INTEGER'
            }
            
            with connection.cursor() as cursor:
                # First fix MPTT fields if they exist
                for column, data_type in mptt_fields.items():
                    if column in existing_columns:
                        # Try to convert any problematic MPTT fields to integers with default 0
                        try:
                            cursor.execute(f"""
                                ALTER TABLE standards_standardsection 
                                ALTER COLUMN {column} TYPE {data_type} USING 0
                            """)
                        except Exception:
                            # If conversion fails, try dropping and recreating the column
                            try:
                                cursor.execute(f"""
                                    ALTER TABLE standards_standardsection 
                                    DROP COLUMN {column}
                                """)
                                cursor.execute(f"""
                                    ALTER TABLE standards_standardsection 
                                    ADD COLUMN {column} {data_type} DEFAULT 0
                                """)
                            except Exception:
                                pass
                
                # Add missing basic columns
                columns_to_add = {
                    'section_number': 'VARCHAR(50) NULL',
                    'title': 'TEXT NULL',
                    'title_user': 'TEXT NULL',
                    'content': 'TEXT NULL',
                    'display_order': 'INTEGER NULL DEFAULT 0',
                }
                
                for column, data_type in columns_to_add.items():
                    if column not in existing_columns:
                        cursor.execute(f"""
                            ALTER TABLE standards_standardsection 
                            ADD COLUMN {column} {data_type}
                        """)
        except Exception as e:
            import logging
            logging.getLogger('django').error(f"Database error: {e}")
            pass
    
    def get_form(self, request, obj=None, **kwargs):
        """Create a form with fields for hierarchical sections"""
        # Check if table exists first
        try:
            from django.db import connection
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables 
                        WHERE table_name = 'standards_standardsection'
                    )
                """)
                table_exists = cursor.fetchone()[0]
                
            if not table_exists:
                # If table doesn't exist, show an error message and use minimal fields
                self.message_user(
                    request, 
                    _("The StandardSection table doesn't exist. Please run 'python manage.py fix_standards_db'."),
                    level='error'
                )
                kwargs['fields'] = ['standard', 'section_number', 'title']
                return super().get_form(request, obj, **kwargs)
        except Exception:
            # Ignore errors checking table existence
            pass
        
        # Ensure basic columns exist
        self.ensure_basic_columns()
        
        # Start with basic fields
        available_fields = ['standard', 'section_number', 'title']
        
        # Add parent field if needed
        parent_id = request.GET.get('parent')
        available_fields.insert(0, 'parent')
        
        # Add other fields if they exist in the database
        try:
            from django.db import connection
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT column_name FROM information_schema.columns 
                    WHERE table_name = 'standards_standardsection'
                """)
                existing_columns = [row[0] for row in cursor.fetchall()]
                
            if 'title_user' in existing_columns:
                available_fields.append('title_user')
                
            if 'content' in existing_columns:
                available_fields.append('content')
        except Exception:
            # Ignore errors checking columns
            pass
        
        # Set up fieldsets
        fieldsets = [
            (_('Section Information'), {
                'fields': ['parent'],
                'description': _('Parent section information')
            }) if parent_id or (obj and obj.parent_id) else None,
            (_('Standard Information'), {
                'fields': ['standard', 'section_number'],
                'description': _('Select the standard and enter the section number')
            }),
            (_('Section Content'), {
                'fields': ['title'] + 
                          (['title_user'] if 'title_user' in available_fields else []) +
                          (['content'] if 'content' in available_fields else []),
                'description': _('Enter section titles in both languages')
            }),
        ]
        
        # Remove None fieldsets
        fieldsets = [f for f in fieldsets if f]
        
        # Set fields and fieldsets
        kwargs['fields'] = available_fields
        self.fieldsets = fieldsets
        
        form = super().get_form(request, obj, **kwargs)
        
        # Customize form fields with better labels and styling
        from django import forms
        if 'title' in form.base_fields:
            form.base_fields['title'].widget = forms.Textarea(attrs={
                'rows': 2,
                'style': 'width: 100%; font-family: "Times New Roman", Times, serif;',
                'placeholder': _('Section Title (Original/Standard Language)')
            })
            form.base_fields['title'].label = _('Original Title')
            form.base_fields['title'].help_text = _('Enter the section title as it appears in the original standard document')
        
        if 'title_user' in form.base_fields:
            form.base_fields['title_user'].widget = forms.Textarea(attrs={
                'rows': 2,
                'style': 'width: 100%; font-family: "Times New Roman", Times, serif;',
                'placeholder': _('Section Title (User/Local Language)')
            })
            form.base_fields['title_user'].label = _('Translated Title')
            form.base_fields['title_user'].help_text = _('Enter a translated or custom title for this section')
            form.base_fields['title_user'].required = False
        
        if 'content' in form.base_fields:
            form.base_fields['content'].widget = forms.Textarea(attrs={
                'rows': 6,
                'style': 'width: 100%; font-family: "Times New Roman", Times, serif;',
                'placeholder': _('Section content')
            })
            form.base_fields['content'].help_text = _('Enter the main content of this section')
            
            # Add a warning about migration issues
            form.base_fields['content'].help_text += _(
                ' Note: If you encounter database issues, please run "python manage.py fix_standards_migrations"'
            )
        
        return form
    
    def save_model(self, request, obj, form, change):
        """Save model with hierarchical relationship handling"""
        try:
            # Make sure we maintain the parent-child relationship
            parent_id = request.GET.get('parent')
            if not change and parent_id and not obj.parent_id:
                try:
                    parent = StandardSection.objects.get(id=parent_id)
                    obj.parent = parent
                    obj.standard = parent.standard
                except StandardSection.DoesNotExist:
                    pass
            
            # Save the object
            obj.save()
        except Exception as e:
            self.message_user(
                request, 
                f"Error saving section: {str(e)}",
                level='error'
            )

# Fix StandardSubsection admin to use a simplified approach
@admin.register(StandardSubsection, site=custom_admin_site)
class StandardSubsectionAdmin(admin.ModelAdmin):
    """Admin for subsections with basic fields only"""
    list_display = ('subsection_number', 'title', 'get_section')  
    search_fields = ('subsection_number', 'title')
    raw_id_fields = ('section',)
    
    # Use only the basic fields to avoid errors
    fields = ['section', 'subsection_number', 'title', 'content']
    
    def get_section(self, obj):
        """Display section safely handling errors"""
        try:
            return obj.section.section_number if obj.section else "-"
        except:
            return "-"
    get_section.short_description = _('Section')
    
    def get_queryset(self, request):
        """Override to handle case where table doesn't exist"""
        try:
            return super().get_queryset(request)
        except Exception as e:
            # If table doesn't exist, return empty queryset
            import logging
            logging.getLogger('django').error(f"Error in StandardSubsectionAdmin.get_queryset: {e}")
            from django.db.models.query import EmptyQuerySet
            return EmptyQuerySet(self.model)
    
    def has_add_permission(self, request):
        """Check if table exists before allowing add"""
        try:
            from django.db import connection
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables 
                        WHERE table_name = 'standards_standardsubsection'
                    )
                """)
                table_exists = cursor.fetchone()[0]
            return table_exists
        except:
            return False
    
    def has_change_permission(self, request, obj=None):
        """Check if table exists before allowing change"""
        return self.has_add_permission(request)
    
    def has_delete_permission(self, request, obj=None):
        """Check if table exists before allowing delete"""
        return self.has_add_permission(request)
    
    def has_view_permission(self, request, obj=None):
        """Check if table exists before allowing view"""
        return self.has_add_permission(request)
    
    def delete_model(self, request, obj):
        """Override to safely handle deletion even if there are database issues"""
        from django.db import connection, transaction
        
        try:
            with transaction.atomic():
                # First try normal ORM deletion
                try:
                    obj.delete()
                    deleted = True
                except Exception as e:
                    deleted = False
                    
                # If ORM fails, try direct SQL
                if not deleted:
                    with connection.cursor() as cursor:
                        cursor.execute(
                            "DELETE FROM standards_standardsubsection WHERE id = %s",
                            [obj.pk]
                        )
                
                self.message_user(
                    request,
                    _("Subsection was successfully deleted."),
                    level='success'
                )
        except Exception as e:
            self.message_user(
                request,
                _("Error deleting subsection: %(error)s") % {'error': str(e)},
                level='error'
            )
            
            # Suggest running the migration fix
            self.message_user(
                request,
                _("Try running 'python manage.py fix_standards_migrations' to resolve database issues."),
                level='warning'
            )
    
    # ...existing code...
    

@admin.register(StandardDocument, site=custom_admin_site)
class StandardDocumentAdmin(admin.ModelAdmin):
    list_display = ('title', 'document_type', 'standard', 'version')
    list_filter = ('document_type', 'standard')
    search_fields = ('title',)


@admin.register(StandardRequirement, site=custom_admin_site)
class StandardRequirementAdmin(admin.ModelAdmin):
    list_display = ('requirement_number', 'section', 'is_mandatory')
    list_filter = ('is_mandatory', 'section__standard')
    search_fields = ('requirement_number',)


@admin.register(StandardAttachment, site=custom_admin_site)
class StandardAttachmentAdmin(admin.ModelAdmin):
    list_display = ('title', 'standard', 'created_at')
    list_filter = ('standard',)
    search_fields = ('title',)


@admin.register(StandardRevision, site=custom_admin_site)
class StandardRevisionAdmin(admin.ModelAdmin):
    list_display = ('revision_number', 'standard', 'revision_date', 'is_current')
    list_filter = ('is_current', 'standard')
    search_fields = ('revision_number',)


@admin.register(StandardComplianceStatus, site=custom_admin_site)
class StandardComplianceStatusAdmin(admin.ModelAdmin):
    list_display = ('standard', 'company', 'status', 'assessment_date')
    list_filter = ('status', 'standard', 'company')
    search_fields = ('company__name', 'standard__number')
